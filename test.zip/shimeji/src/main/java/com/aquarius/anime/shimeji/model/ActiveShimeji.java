package com.aquarius.anime.shimeji.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ActiveShimeji implements Parcelable {
    private int id;
    private int mascotID;
    private double size;
    private double speed;
    private long timeAdded;
    public static final double DEFAULT_SIZE = 1.6;
    public static final double DEFAULT_SPEED = 1.5;

    public ActiveShimeji() {
    }

    public ActiveShimeji(int mascotID) {
        this.mascotID = mascotID;
        this.size = DEFAULT_SIZE;
        this.speed = DEFAULT_SPEED;
    }

    protected ActiveShimeji(Parcel in) {
        id = in.readInt();
        mascotID = in.readInt();
        size = in.readDouble();
        speed = in.readDouble();
        timeAdded = in.readLong();
    }

    public static final Creator<ActiveShimeji> CREATOR = new Creator<ActiveShimeji>() {
        @Override
        public ActiveShimeji createFromParcel(Parcel in) {
            return new ActiveShimeji(in);
        }

        @Override
        public ActiveShimeji[] newArray(int size) {
            return new ActiveShimeji[size];
        }
    };

    public int getId() {
        return id;
    }

    public ActiveShimeji setId(int id) {
        this.id = id;
        return this;
    }

    public int getMascotID() {
        return mascotID;
    }

    public ActiveShimeji setMascotID(int mascotID) {
        this.mascotID = mascotID;
        return this;
    }

    public double getSize() {
        return size;
    }

    public ActiveShimeji setSize(double size) {
        this.size = size;
        return this;
    }

    public double getSpeed() {
        return speed;
    }

    public ActiveShimeji setSpeed(double speed) {
        this.speed = speed;
        return this;
    }

    public long getTimeAdded() {
        return timeAdded;
    }

    public ActiveShimeji setTimeAdded(long timeAdded) {
        this.timeAdded = timeAdded;
        return this;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeInt(mascotID);
        parcel.writeDouble(size);
        parcel.writeDouble(speed);
        parcel.writeLong(timeAdded);
    }
}
