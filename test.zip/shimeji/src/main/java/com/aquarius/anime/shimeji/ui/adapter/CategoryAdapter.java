package com.aquarius.anime.shimeji.ui.adapter;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.databinding.ItemCategoryBinding;
import com.aquarius.anime.shimeji.model.Category;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.util.ArrayList;


public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> implements Filterable {
    private final String TAG = getClass().getSimpleName();

    public interface Listener {
        void OnItemClickListener(int position, Category shimeji);
    }

    private ArrayList<Category> mCategories;
    private ArrayList<Category> mCategoriesFiltered = new ArrayList<>();
    private Listener mListener;


    public CategoryAdapter(ArrayList<Category> categories, Listener listener) {
        this.mCategories = categories;
        this.mListener = listener;
        this.mCategoriesFiltered = categories;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    mCategoriesFiltered = mCategories;
                } else {
                    ArrayList<Category> filteredList = new ArrayList<>();
                    for (Category category : mCategories) {
                        if (category.getName().replaceAll("_", "\\s+").toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(category);
                        }
                    }

                    mCategoriesFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mCategoriesFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mCategoriesFiltered = (ArrayList<Category>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemCategoryBinding binding = ItemCategoryBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new CategoryAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return mCategoriesFiltered.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemCategoryBinding binding;

        public ViewHolder(@NonNull ItemCategoryBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(int position) {
            final Category category = mCategoriesFiltered.get(position);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.OnItemClickListener(position, category);
                }
            });

            binding.imgBg.setCardBackgroundColor(Color.parseColor(Constants.COLORS[position % 5]));

            String name = category.getName().split("\\.")[0].replaceAll("_", " ");
            binding.tvName.setText(name);
            String noOfChar = itemView.getContext().getResources().getQuantityString(R.plurals.number_of_characters, category.getNoOfPet(), category.getNoOfPet());
            binding.tvNoOfCharacter.setText(noOfChar);

            Glide.with(itemView.getContext()).load(category.getThumb()).listener(new RequestListener<Drawable>() {
                @Override
                public boolean onLoadFailed(GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                    return false;
                }

                @Override
                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                    return false;
                }
            }).into(binding.img);
        }

    }

}
