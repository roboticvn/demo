package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class Falling extends Animation {
    private Direction direction = Direction.RIGHT;

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }


    public Falling(MascotConfig config) {
        super(config);
        this.direction = this.random.nextBoolean() ? Direction.LEFT : Direction.RIGHT;
    }

    Falling(Direction direction2, MascotConfig config) {
        super(config);
        this.direction = direction2;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(3, 0, 15, 250));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new Bounce(this.direction, config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return this.direction;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z2;
    }
}
