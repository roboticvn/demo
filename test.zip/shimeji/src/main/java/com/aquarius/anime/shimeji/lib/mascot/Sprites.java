package com.aquarius.anime.shimeji.lib.mascot;

import android.graphics.Bitmap;

import java.util.HashMap;

public class Sprites extends HashMap<Integer, Bitmap> {
    public Sprites(HashMap<Integer, Bitmap> hashMap) {
        if (hashMap == null || hashMap.isEmpty()) {
            //throw new IllegalArgumentException();
        }
        putAll(hashMap);
    }

    public int getWidth() {
        if (size() > 0) {
            return ((Bitmap) get(0)).getWidth();
        }
        return 0;
    }

    public int getHeight() {
        if (size() > 0) {
            return ((Bitmap) get(0)).getHeight();
        }
        return 0;
    }

    public int getXOffset() {
        return getWidth() / 3;
    }

    public void recycle() {
        for (Integer num : keySet()) {
            ((Bitmap) get(num)).recycle();
            put(num, null);
        }
    }
}
