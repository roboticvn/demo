package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class WalkRight extends Walk {
    WalkRight(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(0, 2, 0, 6));
        arrayList.add(new Sprite(1, 2, 0, 6));
        arrayList.add(new Sprite(0, 2, 0, 6));
        arrayList.add(new Sprite(2, 2, 0, 6));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return this.random.nextBoolean() ? new ClimbRight(config) : new WalkLeft(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.RIGHT;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z4;
    }
}
