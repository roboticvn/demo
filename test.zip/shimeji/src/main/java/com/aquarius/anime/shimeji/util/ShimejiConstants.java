package com.aquarius.anime.shimeji.util;

public class ShimejiConstants {
    public static final String EXTRA_ACTIVE_ID = "active_id";
    public static final int SHIMEJI_UNLOCK_COINS = 30;
    public static final String EXTRA_SHIMEJI = "extra_shimeji";
    public static final int SHIMEJI_SPECIAL_ACTION_UNLOCK_COINS = 20;
    public static final String EXTRA_MASCOT_STATUS = "mascot_status";
    public static final String EXTRA_MASCOT_ID = "mascot_id";
}
