package com.aquarius.anime.shimeji.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.ui.dialog.DialogManager;
import com.aquarius.anime.common.util.CommonSettingUtil;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.InternetConnectionUtil;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.common.util.SharedPreferenceUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityCategoryListBinding;
import com.aquarius.anime.shimeji.databinding.ActivityShimejiListBinding;
import com.aquarius.anime.shimeji.model.Category;
import com.aquarius.anime.shimeji.ui.adapter.CategoryAdapter;
import com.aquarius.anime.shimeji.ui.dialog.SelectViewModeDialog;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;

import java.util.ArrayList;

public class CategoryListActivity extends AppCompatActivity {
    private final String TAG = getClass().getSimpleName();

    private Context mContext;
    private CategoryAdapter categoryAdapter;
    ActivityCategoryListBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCategoryListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mContext = this;

        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        binding.btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogManager.getInstance().showDialog(getSupportFragmentManager(), new SelectViewModeDialog(new SelectViewModeDialog.Listener() {
                    @Override
                    public void OnSelectCategoriesMode(boolean enable) {
                        ConfigManager.getInstance().setViewModeCategories(enable);
                        if(!enable) {
                            Intent intent = new Intent(mContext, ShimejiListActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                }), "select_view_mode");
            }
        });
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 2);
        binding.lvCategory.setLayoutManager(layoutManager);

        binding.edtSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.edtSearch.requestFocus();
            }
        });

        binding.edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                Handler mHandler = new Handler();
                mHandler.removeCallbacksAndMessages(null);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Put your call to the server here (with mQueryString)
                        categoryAdapter.getFilter().filter(editable.toString());
                    }
                }, 400);

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ConfigManager.getInstance().isVip()) binding.tvCoin.setVisibility(View.GONE);
        else binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        binding.tvCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().goToPremium(mContext);
            }
        });
        refreshUI();
    }

    private void refreshUI() {
        if (!InternetConnectionUtil.checkConnection(this)) {
            Toast.makeText(this, getString(com.aquarius.anime.common.R.string.no_internet), Toast.LENGTH_SHORT).show();
        }
        ArrayList<Category> categories = ShimejiDAO.getInstance().getCategoryList();
        LogUtil.d(TAG, "categories_size: " + categories.size());
        categoryAdapter = new CategoryAdapter(categories, new CategoryAdapter.Listener() {
            @Override
            public void OnItemClickListener(int position, final Category category) {
                Intent intent = new Intent(mContext, ShimejiListActivity.class);
                intent.putExtra(Constants.INTENT_EXTRA_CATEGORY, category.getName());
                startActivity(intent);
            }
        });
        binding.lvCategory.setAdapter(categoryAdapter);
    }
}
