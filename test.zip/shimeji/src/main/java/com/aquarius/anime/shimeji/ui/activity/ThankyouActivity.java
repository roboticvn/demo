package com.aquarius.anime.shimeji.ui.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.common.util.SharedPreferenceUtil;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityEditShimejiBinding;
import com.aquarius.anime.shimeji.databinding.ActivityThankyouBinding;
import com.aquarius.anime.shimeji.util.ShimejiConstants;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;


public class ThankyouActivity extends BaseActivity {

    public void goHome() {
        Intent intent = new Intent(this, ShimejiSplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private Bitmap mBitmap;
    private int mStatus, mId;
    ActivityThankyouBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityThankyouBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        mStatus = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.HUNGRY);
        mId = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_ID, -1);
        mBitmap = ShimejiDAO.getInstance().getFirstPoseBitmap(mId);
        binding.imageMascot.setImageBitmap(mBitmap);
        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        binding.btnGoHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goHome();
            }
        });
        ConfigManager.getInstance().addCoins(3);
    }
}