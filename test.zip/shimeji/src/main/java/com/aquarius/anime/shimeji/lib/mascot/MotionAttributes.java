package com.aquarius.anime.shimeji.lib.mascot;

public class MotionAttributes {
    private final int INVALID_POINTER_ID = -1;
    public int mActivePointerId = -1;
    public float mLastTouchX;
    public float mLastTouchY;

    public void invalidate() {
        this.mActivePointerId = -1;
    }
}
