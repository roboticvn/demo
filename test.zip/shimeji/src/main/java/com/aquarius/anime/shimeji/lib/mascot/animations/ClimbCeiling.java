package com.aquarius.anime.shimeji.lib.mascot.animations;


import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

abstract class ClimbCeiling extends Animation {
    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    ClimbCeiling(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getOptionalAnimation() {
        return new Falling(getDirection(), config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public int getMaxDuration() {
        return this.random.nextInt(170) + 30;
    }
}
