package com.aquarius.anime.shimeji.lib.mascot;

import android.content.Context;
import android.util.DisplayMetrics;
import com.aquarius.anime.common.util.LogUtil;

public class Playground {
    private final String TAG = getClass().getSimpleName();
    private int bottom;
    private int left;
    private int right;
    private int top;

    private int dpToPx(float f, float f2) {
        return (int) ((f2 * f) + 0.5f);
    }

    public int getTop() {
        return this.top;
    }

    public int getBottom() {
        return this.bottom;
    }

    public int getLeft() {
        return this.left;
    }

    public int getRight() {
        return this.right;
    }

    public Playground(int i, int i2, int i3, int i4) {
        this.top = i;
        this.bottom = i2;
        this.left = i3;
        this.right = i4;
    }

    public Playground(Context context, boolean hasNavigationBar) {
        LogUtil.d(TAG, "Playground: " + hasNavigationBar);
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        //this.bottom = displayMetrics.heightPixels - dpToPx(128.0f, displayMetrics.density);
        if (!hasNavigationBar) {
            this.bottom = displayMetrics.heightPixels - dpToPx(96.0f, displayMetrics.density);
            LogUtil.d(TAG, "identifierdpToPx: " + "  " + dpToPx(96.0f, displayMetrics.density));
        } else {
            int i = 75;
            int identifier = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
            LogUtil.d(TAG, "identifier: " + identifier + "  " + context.getResources().getDimensionPixelSize(identifier));
           // this.bottom = displayMetrics.heightPixels - (identifier > 0 ? context.getResources().getDimensionPixelSize(identifier) : i);
            this.bottom = displayMetrics.heightPixels;
        }
        this.right = displayMetrics.widthPixels;
        this.top = 0;
        this.left = 0;
    }

    //using for only display in shimeji detail activity
    public Playground(Context context, boolean z, int height) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
//        if (z) {
//            this.bottom = height - dpToPx(128.0f, displayMetrics.density);
//        } else {
//            int i = 75;
//            int identifier = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
//            this.bottom = height - (identifier > 0 ? context.getResources().getDimensionPixelSize(identifier) : i);
//        }
        this.bottom = height;
        this.right = displayMetrics.widthPixels;
        this.top = 0;
        this.left = 0;
    }
}
