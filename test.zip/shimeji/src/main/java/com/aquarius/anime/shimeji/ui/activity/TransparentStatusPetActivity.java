package com.aquarius.anime.shimeji.ui.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;

import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityTransparentStatusPetBinding;
import com.aquarius.anime.shimeji.util.ShimejiConstants;


public class TransparentStatusPetActivity extends BaseActivity {
    public static final int DIRTY = 0;
    public static final int HUNGRY = 1;
    public static final int BORING = 2;

    public void onGo() {
        Intent intent = new Intent(this, TakecarePetActivity.class);
        intent.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mId);
        intent.putExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, mStatus);
        startActivity(intent);
        finish();
    }

    private Bitmap mBitmap;
    private int mStatus, mId;
    ActivityTransparentStatusPetBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTransparentStatusPetBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mStatus = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, HUNGRY);
        mId = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_ID, -1);
        binding.btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        binding.btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onGo();
            }
        });
        if (mId < 0) {
            finish();
        }
        if (mStatus == HUNGRY) {
            binding.popupBg.setImageResource(R.drawable.status_hungry);
            binding.tvMsg.setText(getString(R.string.hungry_ms));
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getHungryBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        } else if (mStatus == DIRTY) {
            binding.popupBg.setImageResource(R.drawable.status_dirty);
            binding.tvMsg.setText(getString(R.string.dirty_ms));
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getDirtyBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        } else if (mStatus == BORING) {
            binding.popupBg.setImageResource(R.drawable.status_boring);
            binding.tvMsg.setText(getString(R.string.boring_ms));
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getBoringBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        }
    }
}