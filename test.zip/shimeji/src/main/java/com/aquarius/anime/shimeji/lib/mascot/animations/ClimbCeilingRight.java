package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public class ClimbCeilingRight extends ClimbCeiling {
    ClimbCeilingRight(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(24, 0, 0, 16));
        arrayList.add(new Sprite(24, 1, 0, 4));
        arrayList.add(new Sprite(22, 1, 0, 4));
        arrayList.add(new Sprite(23, 1, 0, 4));
        arrayList.add(new Sprite(23, 0, 0, 16));
        arrayList.add(new Sprite(23, 2, 0, 4));
        arrayList.add(new Sprite(22, 2, 0, 4));
        arrayList.add(new Sprite(24, 2, 0, 4));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return this.random.nextBoolean() ? new DescendRight(config) : new ClimbCeilingLeft(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.RIGHT;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z4;
    }
}
