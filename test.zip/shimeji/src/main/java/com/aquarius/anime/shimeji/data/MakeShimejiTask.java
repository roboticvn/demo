package com.aquarius.anime.shimeji.data;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;

import androidx.documentfile.provider.DocumentFile;

import com.aquarius.anime.common.util.AppContextHolder;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.util.BitmapUtil;
import com.aquarius.anime.shimeji.util.ShimejiConfig;

import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MakeShimejiTask {
    private final String TAG = getClass().getSimpleName();

    public interface Listener {
        void OnMakeShimejiSuccess();

        void OnMakeShimejiFail(String msg);
    }

    public MakeShimejiTask() {

    }

    public void execute(String shimejiName, DocumentFile folder, Listener listener) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                DocumentFile[] fileArr = folder.listFiles();
                if (fileArr == null) fileArr = new DocumentFile[0];

                // Tạo map để lookup nhanh
                Map<String, DocumentFile> fileMap = new HashMap<>();
                for (DocumentFile f : fileArr) {
                    String name = f.getName();
                    if (name != null && name.toLowerCase().endsWith(".png")) {
                        fileMap.put(name.toLowerCase(), f);
                    }
                }

                int id = ShimejiConfig.getIdIncreasement();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
                File thumbFile = new File(AppContextHolder.getContext().getFilesDir(),
                        id + "_" + sdf.format(new Date()) + ".png");

                // thumb từ file đầu tiên
                DocumentFile firstFile = !fileMap.isEmpty() ? fileMap.values().iterator().next() : null;
                if (firstFile != null) {
                    try (InputStream is = AppContextHolder.getContext().getContentResolver().openInputStream(firstFile.getUri())) {
                        Bitmap thumb = BitmapFactory.decodeStream(is);
                        BitmapUtil.saveBitmapToFile(thumb, thumbFile.getAbsolutePath());
                    }
                }

                SimpleDateFormat sdfDB = new SimpleDateFormat(Constants.FORMAT_DATE);
                Shimeji shimeji = new Shimeji().setMascotID(id)
                        .setName(shimejiName)
                        .setCategories("DIY")
                        .setThumb(thumbFile.getAbsolutePath())
                        .setUrl("")
                        .setLock(0)
                        .setSpecialLock(0)
                        .setSpecial2Lock(0)
                        .setCreated(sdfDB.format(new Date()));
                if (fileMap.size() < 46) shimeji.setSpecialLock(-1).setSpecial2Lock(-1);
                ShimejiDAO.getInstance().insertShimeji(shimeji);

                ArrayList<Bitmap> bitmaps = new ArrayList<>();
                for (int i = 1; i <= 46; i++) {
                    DocumentFile file = fileMap.get(("shime" + i + ".png").toLowerCase());
                    Bitmap bitmap;
                    if (file != null) {
                        try (InputStream is = AppContextHolder.getContext().getContentResolver().openInputStream(file.getUri())) {
                            bitmap = BitmapFactory.decodeStream(is);
                        }
                    } else {
                        bitmap = BitmapUtil.createTransparentBitmap(128, 128);
                    }
                    bitmaps.add(bitmap);
                }

                ShimejiDAO.getInstance().insertMascotBitmaps(id, bitmaps);
                ShimejiConfig.saveIdIncreasement();

                new Handler(Looper.getMainLooper()).post(listener::OnMakeShimejiSuccess);

            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(() -> listener.OnMakeShimejiFail(e.getMessage()));
            } finally {
                executorService.shutdown(); // tránh leak
            }
        });
    }

}
