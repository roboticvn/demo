package com.aquarius.anime.shimeji.ui.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.aquarius.anime.common.ui.dialog.BaseDialogFragment;
import com.aquarius.anime.shimeji.databinding.DialogAddShimejiBinding;

public class AddShimejiDialog extends BaseDialogFragment {
    public interface Listener {
        void OnMakeShimeji();

        void OnSelectFromList();

        void OnCancel();
    }

    private Listener mListener;


    public AddShimejiDialog() {

    }

    public AddShimejiDialog(Listener listener) {
        mListener = listener;
    }

    private DialogAddShimejiBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCancelable(false);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), com.aquarius.anime.common.R.style.RoundDialogTheme);
        binding = DialogAddShimejiBinding.inflate(LayoutInflater.from(getContext()));
        dialog.setContentView(binding.getRoot());


        // Set up button listeners
        binding.btnCreateNew.setOnClickListener(v -> {
            if (mListener != null) mListener.OnMakeShimeji();
            dismiss();
        });

        binding.btnFromList.setOnClickListener(v -> {
            if (mListener != null) mListener.OnSelectFromList();
            dismiss();
        });

        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.OnCancel();
                dismiss();
            }
        });
        return dialog;
    }
}


