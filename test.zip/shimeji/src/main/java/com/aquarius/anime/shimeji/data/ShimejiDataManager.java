package com.aquarius.anime.shimeji.data;

import com.aquarius.anime.common.event.AppEvents;
import com.aquarius.anime.common.util.JsonUtils;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.api.ShimejiApi;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.model.ShimejiMap;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONObject;

public class ShimejiDataManager {

    private static final String TAG = "ShimejiDataManager";

    private ShimejiDataManager() {
    }

    public static void syncAllData() {
        LogUtil.d(TAG, "syncAllData started");
        fetchShimeji();
        fetchShimejiMap();
        LogUtil.d(TAG, "syncAllData finished");
    }

    private static void fetchShimeji() {
        try {
            boolean dataInserted = false;

            JSONObject json = JsonUtils.safeParseJson(ShimejiApi.fetchShimejiJson());
            if (json == null) {
                LogUtil.e(TAG, "Failed to fetch or parse Shimeji JSON");
                return;
            }

            JSONArray jdata = json.optJSONArray("data");
            if (jdata == null || jdata.length() == 0) {
                LogUtil.d(TAG, "No data found in Shimeji JSON");
                return;
            }

            LogUtil.d(TAG, "Data_length: " + jdata.length());
            for (int i = 0; i < jdata.length(); i++) {
                JSONObject obj = jdata.optJSONObject(i);
                Shimeji item = parseShimeji(obj);
                LogUtil.d(TAG, "item: " + item.getMascotID() + " - " + item.getName());
                if (item != null) {
                    long result = ShimejiDAO.getInstance().insertShimeji(item);
                    if (result >= 0) dataInserted = true;
                }
            }

            if (dataInserted) {
                EventBus.getDefault().post(new AppEvents.DataEvent(AppEvents.DataEvent.Type.SHIMEJI_CHANGED));
                LogUtil.d(TAG, "Shimeji data updated and event posted.");
            } else {
                LogUtil.d(TAG, "No new shimeji data inserted.");
            }
        } catch (Exception e) {
            LogUtil.e(TAG, "fetchShimeji: " + e.getMessage());
        }
    }

    private static void fetchShimejiMap() {
        try {
            JSONObject json = JsonUtils.safeParseJson(ShimejiApi.fetchShimejiMapJson());
            if (json == null) {
                LogUtil.e(TAG, "Failed to fetch or parse Shimeji Map JSON");
                return;
            }

            JSONArray jdata = json.optJSONArray("data");
            if (jdata == null || jdata.length() == 0) {
                LogUtil.d(TAG, "No data found in Shimeji Map JSON");
                return;
            }

            LogUtil.d(TAG, "fetchShimejiMap_Data_length: " + jdata.length());
            for (int i = 0; i < jdata.length(); i++) {
                JSONObject obj = jdata.optJSONObject(i);
                ShimejiMap item = parseShimejiMap(obj);
                if (item != null) {
                    long result = ShimejiDAO.getInstance().insertShimejiMap(item);
                    LogUtil.d(TAG, "insertShimejiMap_result: " + item.getId() + " -> " + result);
                }
            }
        } catch (Exception e) {
            LogUtil.e(TAG, "fetchShimejiMap: " + e.getMessage());
        }
    }

    private static Shimeji parseShimeji(JSONObject obj) {
        if (obj == null) return null;

        return new Shimeji()
                .setMascotID(obj.optInt("id"))
                .setName(obj.optString("name"))
                .setCategories(obj.optString("categories"))
                .setThumb(obj.optString("thumb"))
                .setUrl(obj.optString("url"))
                .setAuthor(obj.optString("author"))
                .setLock(obj.optInt("full_lock"))
                .setSpecialLock(obj.optInt("special_lock"))
                .setSpecial2Lock(obj.optInt("special2_lock"))
                .setCreated(obj.optString("created"));
    }

    private static ShimejiMap parseShimejiMap(JSONObject obj) {
        if (obj == null) return null;
        return new ShimejiMap()
                .setId(obj.optInt("id"))
                .setUrl(obj.optString("url"));
    }
}
