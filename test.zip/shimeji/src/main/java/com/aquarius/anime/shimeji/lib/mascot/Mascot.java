package com.aquarius.anime.shimeji.lib.mascot;

import android.graphics.Bitmap;
import android.view.MotionEvent;

import com.aquarius.anime.shimeji.lib.mascot.animations.Dragging;
import com.aquarius.anime.shimeji.lib.mascot.animations.Falling;
import com.aquarius.anime.shimeji.lib.mascot.animations.Flinging;
import com.aquarius.anime.shimeji.lib.mascot.animations.ZFalling;
import com.aquarius.anime.shimeji.lib.mascot.animations.ZSpecial2LeftPreview;
import com.aquarius.anime.shimeji.lib.mascot.animations.ZSpecialLeftPreview;
import com.aquarius.anime.shimeji.lib.mascot.animations.Animation;
import java.util.Random;

public class Mascot {
    private Animation animation;
    private MascotConfig config;
    private int dx;
    private int dy;
    private int flingVelocityX;
    private int flingVelocityY;
    private Sprites frames;
    private int height;
    private boolean isBeingDragged = false;
    private boolean isBeingFlung = false;
    public volatile boolean isFacingLeft;
    private Playground margins;
    private double speedMultiplier;
    private MascotThread thread;
    private MotionAttributes touch = new MotionAttributes();
    private int width;
    private int xOffset;

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private int getAnimationDelay() {
        return 30;
    }

    public int getX() {
        return this.dx;
    }

    public int getY() {
        return this.dy;
    }

    public Bitmap getFrameBitmap() {
        return (Bitmap) this.frames.get(Integer.valueOf(this.animation.getSpriteIdentifier()));
    }

    public void startAnimation() {
        MascotThread mascotThread = new MascotThread();
        this.thread = mascotThread;
        if (mascotThread.getState() == Thread.State.NEW) {
            this.thread.start();
        }
    }

    public void initialize(Sprites sprites, double d, Playground playground, MascotConfig config) {
        this.config = config;
        loadBitmaps(sprites);
        setPlayground(new Playground(playground.getTop() - this.xOffset, playground.getBottom(), playground.getLeft() - this.xOffset, playground.getRight() + this.xOffset));
        setSpeedMultiplier(d);
        if (config.mode == MascotConfig.RUN_ON_SCREEN)
            this.animation = new Falling(config);
        else if (config.mode == MascotConfig.SHOW_DETAIL)
            this.animation = new ZFalling(config);
        else if (config.mode == MascotConfig.ONLY_SHOW_SPECIAL1)
            this.animation = new ZSpecialLeftPreview(config);
        else if (config.mode == MascotConfig.ONLY_SHOW_SPECIAL2)
            this.animation = new ZSpecial2LeftPreview(config);

        setX(new Random().nextInt(this.margins.getRight() - this.width));
    }

    public void setSpeedMultiplier(double d) {
        this.speedMultiplier = d <= 0.1d ? 1.0d : d + 0.9d;
    }

    public void resetEnvironmentVariables(Playground playground) {
        setPlayground(new Playground(playground.getTop(), playground.getBottom(), playground.getLeft() - this.xOffset, playground.getRight() + this.xOffset));
        this.animation = new Falling(config);
    }

    private void setPlayground(Playground playground) {
        this.margins = playground;
    }

    private class MascotThread extends Thread {
        volatile boolean isRunning;

        private MascotThread() {
            this.isRunning = true;
        }

        public void run() {
            while (this.isRunning) {
                try {
                    Mascot.this.updateAnimation();
                    Thread.sleep((long) Mascot.this.getAnimationDelay());
                } catch (InterruptedException unused) {
                    this.isRunning = false;
                }
            }
        }
    }

    private void moveManually(int i, int i2) {
        setX(i);
        setY(i2);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void updateAnimation() {
        checkConditions();
        double xVelocity = (double) this.animation.getXVelocity();
        double d = this.speedMultiplier;
        Double.isNaN(xVelocity);
        applyVelocityX((int) (xVelocity * d));
        double yVelocity = (double) this.animation.getYVelocity();
        double d2 = this.speedMultiplier;
        Double.isNaN(yVelocity);
        applyVelocityY((int) (yVelocity * d2));
        this.isFacingLeft = this.animation.isFacingLeft();
        this.animation = this.animation.frameTick();
    }

    private void checkConditions() {
        if (this.isBeingDragged) {
            if (!(this.animation instanceof Dragging)) {
                this.animation = new Dragging(config);
            }
        } else if (!this.isBeingFlung) {
            Animation animation2 = this.animation;
            if (animation2 instanceof Dragging) {
                this.animation = ((Dragging) animation2).drop();
            } else if (animation2 instanceof Flinging) {
                this.animation = ((Flinging) animation2).drop();
            }
        } else if (!(this.animation instanceof Flinging)) {
            this.animation = new Flinging(this.flingVelocityX, config);
        }
        Animation animation3 = this.animation;
        boolean z = true;
        boolean z2 = this.dy <= this.margins.getTop();
        boolean z3 = this.dy + this.height >= this.margins.getBottom();
        boolean z4 = this.dx <= this.margins.getLeft();
        if (this.dx + this.width < this.margins.getRight()) {
            z = false;
        }
        animation3.checkBorders(z2, z3, z4, z);
    }

    private void setX(int i) {
        if (i < this.margins.getLeft()) {
            this.dx = this.margins.getLeft();
        } else if (i > this.margins.getRight() - this.width) {
            this.dx = this.margins.getRight() - this.width;
        } else {
            this.dx = i;
        }
    }

    private void setY(int i) {
        if (i > this.margins.getBottom() - this.height) {
            this.dy = this.margins.getBottom() - this.height;
        } else if (i < this.margins.getTop()) {
            this.dy = this.margins.getTop();
        } else {
            this.dy = i;
        }
    }

    /* access modifiers changed from: package-private */
    public void drag(int i, int i2) {
        setX(i);
        setY(i2);
        this.isBeingDragged = true;
    }

    /* access modifiers changed from: package-private */
    public boolean isBeingFlung() {
        return this.isBeingFlung;
    }

    /* access modifiers changed from: package-private */
    public void setFlingSpeed(int i, int i2) {
        this.flingVelocityX = i;
        this.flingVelocityY = i2;
        this.isBeingFlung = true;
    }

    /* access modifiers changed from: package-private */
    public void fling(int i, int i2) {
        setX(i);
        setY(i2);
        this.isBeingDragged = false;
    }

    /* access modifiers changed from: package-private */
    public void endDragging() {
        this.isBeingDragged = false;
    }

    /* access modifiers changed from: package-private */
    public void endFlinging() {
        this.isBeingFlung = false;
    }

    public boolean handleTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        int i = 1;
        int i2 = 0;
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                        if (actionMasked == 6 && this.isBeingDragged) {
                            this.isBeingDragged = false;
                            int actionIndex = motionEvent.getActionIndex();
                            if (motionEvent.getPointerId(actionIndex) == this.touch.mActivePointerId) {
                                if (actionIndex != 0) {
                                    i = 0;
                                }
                                this.touch.mLastTouchX = motionEvent.getX(i);
                                this.touch.mLastTouchY = motionEvent.getY(i);
                                this.touch.mActivePointerId = motionEvent.getPointerId(i);
                            }
                        }
                    }
                } else if (this.isBeingDragged) {
                    int findPointerIndex = motionEvent.findPointerIndex(this.touch.mActivePointerId);
                    if (findPointerIndex != -1) {
                        i2 = findPointerIndex;
                    }
                    float x = motionEvent.getX(i2);
                    float y = motionEvent.getY(i2);
                    moveManually(((int) (x - this.touch.mLastTouchX)) + this.dx, ((int) (y - this.touch.mLastTouchY)) + this.dy);
                    this.touch.mLastTouchX = x;
                    this.touch.mLastTouchY = y;
                }
            }
            if (this.isBeingDragged) {
                this.touch.invalidate();
                this.isBeingDragged = false;
            }
        } else {
            int actionIndex2 = motionEvent.getActionIndex();
            float x2 = motionEvent.getX(actionIndex2);
            float y2 = motionEvent.getY(actionIndex2);
            if (motionEvent.getX() > ((float) (this.dx - 20)) && motionEvent.getY() > ((float) (this.dy - 20)) && motionEvent.getX() < ((float) (this.dx + this.width + 20)) && motionEvent.getY() < ((float) (this.dy + this.height + 20))) {
                this.isBeingDragged = true;
                this.touch.mLastTouchX = x2;
                this.touch.mLastTouchY = y2;
                this.touch.mActivePointerId = motionEvent.getPointerId(0);
            }
        }
        return this.isBeingDragged;
    }

    private void loadBitmaps(Sprites sprites) {
        this.frames = sprites;
        this.height = sprites.getHeight();
        this.width = this.frames.getWidth();
        this.xOffset = this.frames.getXOffset();
    }

    private void applyVelocityX(int i) {
        setX(this.dx + i);
    }

    private void applyVelocityY(int i) {
        setY(this.dy + i);
    }

    public void kill() {
        MascotThread mascotThread = this.thread;
        if (mascotThread != null) {
            mascotThread.isRunning = false;
            this.thread.interrupt();
        }
    }
}