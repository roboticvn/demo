package com.aquarius.anime.shimeji.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;

import com.aquarius.anime.common.sec.SecLib;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.lib.mascot.Sprites;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class BitmapUtil {
    static final String TAG = "BitmapUtil";
    public static byte[] bitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return SecLib.encrypt(byteArrayOutputStream.toByteArray());
    }

    public static Bitmap byteArrayToBitmap(byte[] bArr) {
        try {
            return BitmapFactory.decodeStream(new ByteArrayInputStream(SecLib.decrypt(bArr)));
        } catch (Exception e) {
            //return createTransparentBitmap(128, 128);
            LogUtil.e(TAG, e.getMessage());
        }
        return null;
    }

    private static Bitmap getResizedBitmap(Bitmap bitmap, float f) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(f, f);
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, false);
    }

    public static Sprites resizeSprites(Sprites sprites, double d) {
        for (Integer num : sprites.keySet()) {
            sprites.put(num, getResizedBitmap((Bitmap) sprites.get(num), (float) d));
        }
        return sprites;
    }

    public static Bitmap createTransparentBitmap(int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.TRANSPARENT); // Set the entire bitmap to transparent color
        return bitmap;
    }

    public static Bitmap getBitmapFromFile(File file) {
        return BitmapFactory.decodeFile(file.getAbsolutePath());
    }

    public static void saveBitmapToFile(Bitmap bitmap, String destPath) throws IOException {
        try (FileOutputStream out = new FileOutputStream(destPath)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); // bmp is your Bitmap instance
            // PNG is a lossless format, the compression factor (100) is ignored
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
