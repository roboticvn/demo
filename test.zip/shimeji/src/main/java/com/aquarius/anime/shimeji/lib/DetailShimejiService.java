package com.aquarius.anime.shimeji.lib;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.aquarius.anime.common.util.DpPixelConverter;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.lib.mascot.MascotView;
import com.aquarius.anime.shimeji.lib.mascot.Playground;
import com.aquarius.anime.shimeji.model.ActiveShimeji;

import java.util.HashMap;

public class DetailShimejiService extends Service {
    private final String TAG = getClass().getSimpleName();
    private Handler handler;
    private WindowManager mWindowManager;
    private MascotView mMascotView;

    private HashMap<Long, WindowManager.LayoutParams> viewParams = new HashMap<>();

    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        public DetailShimejiService getService() {
            return DetailShimejiService.this;
        }
    }

    public DetailShimejiService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public void onCreate() {
        super.onCreate();
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.handler = new Handler(new Handler.Callback() {
            /* class com.digitalcosmos.shimeji.displayservice.ShimejiService.AnonymousClass1 */

            public boolean handleMessage(Message message) {
                return DetailShimejiService.this.onHandleMessage(message);
            }
        });
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        return START_NOT_STICKY;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        removeMascotView();
        return super.onUnbind(intent);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    public void initMascotViews(ActiveShimeji activeShimeji, MascotConfig config) {
        removeMascotView();
        WindowManager.LayoutParams layoutParams;
        if (Build.VERSION.SDK_INT >= 26) {
            layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, 520, PixelFormat.TRANSLUCENT);
        } else {
            layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_PHONE, 520, PixelFormat.TRANSLUCENT);
        }
        layoutParams.gravity = 8388659;

        Playground playground = new Playground(this, false, (int) DpPixelConverter.convertDpToPixel(200, this));
        mMascotView = new MascotView(this, activeShimeji, config, playground);

        layoutParams.width = mMascotView.width;
        layoutParams.height = mMascotView.height;
        this.viewParams.put(Long.valueOf(mMascotView.getUniqueId()), layoutParams);
        try {
            this.mWindowManager.addView(mMascotView, layoutParams);
        } catch (WindowManager.BadTokenException | SecurityException unused) {

        }

        this.handler.sendEmptyMessage(1);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    public void removeMascotView() {
        LogUtil.d(TAG, "removeMascotView");
        this.handler.removeMessages(1);
        if (mMascotView != null && mMascotView.isShown()) {
            mMascotView.pauseAnimation();
            this.mWindowManager.removeViewImmediate(mMascotView);
        }
        this.viewParams.clear();
    }

    public void updateSpeedMascotView(ActiveShimeji activeShimeji) {
        if (mMascotView != null)
            mMascotView.setSpeedMultiplier(activeShimeji.getSpeed());
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private boolean onHandleMessage(Message message) {
        if (message.what != 1) {
            return false;
        }
        this.handler.removeMessages(1);

        if (mMascotView.isHidden && mMascotView.isAnimationRunning) {
            this.mWindowManager.addView(mMascotView, this.viewParams.get(Long.valueOf(mMascotView.getUniqueId())));
            mMascotView.isHidden = false;
        }
        if (mMascotView.isAnimationRunning) {
            WindowManager.LayoutParams layoutParams = this.viewParams.get(Long.valueOf(mMascotView.getUniqueId()));
            layoutParams.height = mMascotView.height;
            layoutParams.width = mMascotView.width;
            layoutParams.x = (int) mMascotView.getX();
            layoutParams.y = (int) mMascotView.getY();
            this.mWindowManager.updateViewLayout(mMascotView, layoutParams);
        }

        this.handler.sendEmptyMessageDelayed(1, 16);
        return true;
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.orientation == 2 || configuration.orientation == 1) {
            try {
                mMascotView.notifyLayoutChange(this);
            } catch (Exception e) {

            }
        }
    }
}