package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;

/* access modifiers changed from: package-private */
public abstract class Walk extends Animation {
    private final String TAG = getClass().getSimpleName();

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    Walk(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getOptionalAnimation() {
        //LogUtil.d(TAG, "mode_: " + config.mode);
        ArrayList<Animation> animations = new ArrayList<>();
        if (config.mode == MascotConfig.ONLY_SHOW_SPECIAL1) {
            return new ZSpecialLeftPreview(config);
        } else if (config.mode == MascotConfig.ONLY_SHOW_SPECIAL2) {
            return new ZSpecial2LeftPreview(config);
        } else if (config.mode == MascotConfig.SHOW_DETAIL) {
            animations.add(new ZSit(getDirection(), config));
            animations.add(new ZStand(getDirection(), config));
            animations.add(new ZWink(getDirection(), config));
            animations.add(new ZSitAndDangleLegs(getDirection(), config));
            animations.add(new ZSitWithLegsDown(getDirection(), config));
            animations.add(new ZSitAndLookUp(getDirection(), config));
            animations.add(getDirection() == Direction.LEFT ? new ZTrippingLeft(config) : new ZTrippingRight(config));
            //animations.add(getDirection() == Direction.LEFT ? new ZCreepLeft(config) : new ZCreepRight(config));
            if (config.showSpecial==MascotConfig.UNLOCK)
                animations.add(getDirection() == Direction.LEFT ? new ZSpecialLeft(config) : new ZSpecialRight(config));
            if (config.showSpecial2==MascotConfig.UNLOCK)
                animations.add(getDirection() == Direction.LEFT ? new ZSpecial2Left(config) : new ZSpecial2Right(config));
            return animations.get(this.random.nextInt(animations.size()));
        } else {
            animations.add(new Sit(getDirection(), config));
            animations.add(new Stand(getDirection(), config));
            animations.add(new Wink(getDirection(), config));
            animations.add(new SitAndDangleLegs(getDirection(), config));
            animations.add(new SitWithLegsDown(getDirection(), config));
            animations.add(new SitAndLookUp(getDirection(), config));
            animations.add(getDirection() == Direction.LEFT ? new TrippingLeft(config) : new TrippingRight(config));
            animations.add(getDirection() == Direction.LEFT ? new CreepLeft(config) : new CreepRight(config));
            if (config.showSpecial==MascotConfig.UNLOCK)
                animations.add(getDirection() == Direction.LEFT ? new SpecialLeft(config) : new SpecialRight(config));
            if (config.showSpecial2==MascotConfig.UNLOCK)
                animations.add(getDirection() == Direction.LEFT ? new Special2Left(config) : new Special2Right(config));
            return animations.get(this.random.nextInt(animations.size()));
        }
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public int getMaxDuration() {
        int nextInt;
        nextInt = this.random.nextInt(60);
        return nextInt + 10;
    }
}
