package com.aquarius.anime.shimeji.lib.mascot.animations;

/* access modifiers changed from: package-private */
public class Sprite {
    int duration;
    int index;
    int xVelocity;
    int yVelocity;

    Sprite(int i, int i2, int i3, int i4) {
        this.index = i;
        this.xVelocity = i2;
        this.yVelocity = i3;
        this.duration = i4;
    }
}
