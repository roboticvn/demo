package com.aquarius.anime.shimeji.ui.dialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.aquarius.anime.common.R;
import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.databinding.DialogUnlockItemBinding;
import com.aquarius.anime.common.ui.dialog.BaseDialogFragment;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.DpPixelConverter;
import com.aquarius.anime.shimeji.databinding.DialogUnlockSpecialActionBinding;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.lib.mascot.MascotView;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.util.ShimejiConstants;


public class UnlockSpecialActionDialog extends BaseDialogFragment {
    public interface Listener {

        void OnPremium();

        void OnUnlockByCoin();

        void OnCancel();
    }
    private int mMascotID;
    private int mMascotMode;
    private Listener mListener;
    private int mUnlockCoins = ShimejiConstants.SHIMEJI_SPECIAL_ACTION_UNLOCK_COINS;

    public UnlockSpecialActionDialog() {

    }

    public UnlockSpecialActionDialog(int mascotId, int mascotMode, Listener listener) {
        this.mMascotID = mascotId;
        this.mMascotMode = mascotMode;
        this.mListener = listener;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setCancelable(false);
    }

    DialogUnlockSpecialActionBinding binding;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), R.style.RoundDialogTheme);
        binding = DialogUnlockSpecialActionBinding.inflate(LayoutInflater.from(getContext()));
        dialog.setContentView(binding.getRoot());
        binding.btnUnlockByCoin.setText(getString(R.string.unlock_by_coins, mUnlockCoins));

        binding.btnPremiumPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.OnPremium();
                dismiss();
            }
        });

        binding.btnEarnCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.OnPremium();
                dismiss();
            }
        });

        binding.btnUnlockByCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ConfigManager.getInstance().getCoins() < Constants.DEFAULT_SPECIAL_ACTION_UNLOCK_COINS) {
                    Toast.makeText(getContext(), getString(com.aquarius.anime.shimeji.R.string.need_more_coins), Toast.LENGTH_SHORT).show();
                } else {
                    mListener.OnUnlockByCoin();
                    dismiss();
                }
            }
        });
        ActiveShimeji activeShimeji = new ActiveShimeji(mMascotID);
        activeShimeji.setSize(2);
        MascotConfig config = new MascotConfig(mMascotMode, MascotConfig.UNLOCK, MascotConfig.UNLOCK);
        MascotView mascotView = new MascotView(getContext(), activeShimeji, config, new MascotView.MascotClickListener() {
            @Override
            public void OnDoubleClick() {

            }

            @Override
            public void OnSingleClick() {

            }
        });

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        int topMargin = (int) DpPixelConverter.convertDpToPixel(24, getContext());
        layoutParams.setMargins(0, topMargin, 0, 0);

        layoutParams.width = mascotView.width;
        layoutParams.height = mascotView.height;
        binding.mascotviewWrapper.addView(mascotView, layoutParams);
        return dialog;
    }

    @Override
    public void onCancel(@NonNull DialogInterface dialog) {
        super.onCancel(dialog);
        mListener.OnCancel();
    }
}
