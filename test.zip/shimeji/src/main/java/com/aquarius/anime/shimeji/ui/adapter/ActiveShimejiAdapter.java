package com.aquarius.anime.shimeji.ui.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ItemActiveShimejiBinding;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ActiveShimejiAdapter extends RecyclerView.Adapter<ActiveShimejiAdapter.ViewHolder> {
    private final String TAG = getClass().getSimpleName();

    public interface Listener {
        void OnRemoveShimejiListener(ActiveShimeji shimeji);

        void OnAddShimejiListener();

        void OnShimejiClickListener(ActiveShimeji shimeji);
    }

    private ArrayList<ActiveShimeji> mShimeji;
    private Listener mListener;


    public ActiveShimejiAdapter(ArrayList<ActiveShimeji> shimejis, Listener listener) {
        this.mShimeji = shimejis;
        this.mListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemActiveShimejiBinding binding = ItemActiveShimejiBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return mShimeji.size() + 1;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemActiveShimejiBinding binding;

        public ViewHolder(ItemActiveShimejiBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(final int position) {
            if (position == mShimeji.size()) {
                binding.shimejiLayout.setVisibility(View.GONE);
                binding.btnAddLayout.setVisibility(View.VISIBLE);

                binding.imgAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (position == mShimeji.size()) {
                            mListener.OnAddShimejiListener();
                        }
                    }
                });
            } else {
                ActiveShimeji item = mShimeji.get(position);
                final Shimeji shimeji = ShimejiDAO.getInstance().getShimejiByID(item.getMascotID());
                Log.i(TAG, "active_shimeji: " + shimeji.getName());
                binding.shimejiLayout.setVisibility(View.VISIBLE);
                binding.btnAddLayout.setVisibility(View.GONE);
                //binding.img.setBackgroundColor(Color.parseColor(Constants.COLORS[position % 5]));
                binding.imgRemove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.OnRemoveShimejiListener(item);
                    }
                });
                binding.img.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.OnShimejiClickListener(item);
                    }
                });

                LogUtil.d("shimeji_thumb", shimeji.getThumb());
                Glide.with(itemView.getContext()).load(shimeji.getThumb()).into(binding.img);
            }
        }
    }

}
