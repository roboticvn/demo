package com.aquarius.anime.shimeji.background;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.network.SimpleDownloader;
import com.aquarius.anime.common.sec.SecLib;
import com.aquarius.anime.common.util.AppContextHolder;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.api.ShimejiApi;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.util.BitmapUtil;

import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ShimejiDownloader {

    public interface Listener {
        void onSuccess();
        void onError();
    }

    private static final ExecutorService executor = Executors.newFixedThreadPool(4);

    // Hàm mới: nhận Shimeji object, parse url để lấy id và fileName
    public static void downloadShimeji(Shimeji shimeji, Listener listener) {
        if (shimeji == null || shimeji.getUrl() == null || shimeji.getUrl().isEmpty()) {
            if (listener != null) runOnUiThread(listener::onError);
            return;
        }

        String[] parts = shimeji.getUrl().split("/");
        if (parts.length < 2) {
            if (listener != null) runOnUiThread(listener::onError);
            return;
        }

        int id;
        String fileName;
        try {
            id = Integer.parseInt(parts[parts.length - 2]);
            fileName = parts[parts.length - 1];
        } catch (NumberFormatException e) {
            if (listener != null) runOnUiThread(listener::onError);
            return;
        }

        downloadShimeji(id, fileName, shimeji.getUrl(), listener);
    }

    // Hàm gốc giữ nguyên
    public static void downloadShimeji(int id, String fileName, String githubUrl, Listener listener) {
        executor.submit(() -> {
            File downloadedFile = null;

            if (ConfigManager.getInstance().isOnlySelfHost()) {
                downloadedFile = downloadFromSelfHost(id, fileName);
            } else {
                downloadedFile = downloadFromGithub(id, fileName, githubUrl);
                if (downloadedFile == null && ConfigManager.getInstance().isFallbackSelfHost()) {
                    downloadedFile = downloadFromSelfHost(id, fileName);
                }
            }

            if (downloadedFile != null) {
                insertShimeji(id, downloadedFile, listener);
            } else {
                runOnUiThread(listener::onError);
            }
        });
    }

    private static File downloadFromSelfHost(int id, String fileName) {
        String url = ShimejiApi.getSelfHostShimejiUrl(id, fileName);
        LogUtil.d("ShimejiDownloader", "SelfHost URL: " + url);
        return SimpleDownloader.download(url, getTargetFile(fileName));
    }

    private static File downloadFromGithub(int id, String fileName, String originUrl) {
        LogUtil.d("ShimejiDownloader", "Github URL: " + originUrl);
        return SimpleDownloader.download(originUrl, getTargetFile(fileName));
    }

    private static File getTargetFile(String fileName) {
        return new File(AppContextHolder.getContext().getFilesDir() + File.separator
                + Constants.AppType.SHIMEJI + File.separator + fileName);
    }

    private static void insertShimeji(int id, File zipFile, Listener listener) {
        File folder = new File(AppContextHolder.getContext().getFilesDir(), Constants.AppType.SHIMEJI);
        String subFolderName = zipFile.getName().replace(".zip", "");
        File extractTargetDir = new File(folder, subFolderName);
        if (!extractTargetDir.exists()) extractTargetDir.mkdirs();

        try {
            File decryptedFile = new File(folder, subFolderName + "_decrypted.zip");
            SecLib.decryptFile(zipFile, decryptedFile);
            ZipFile zip = new ZipFile(decryptedFile.getCanonicalPath());
            zip.extractAll(extractTargetDir.getCanonicalPath());

            if (saveBitmaps(id, extractTargetDir)) {
                runOnUiThread(listener::onSuccess);
            } else {
                runOnUiThread(listener::onError);
            }
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(listener::onError);
        }
    }

    private static boolean saveBitmaps(int mascotID, File folder) {
        ArrayList<Bitmap> bitmaps = new ArrayList<>();
        int validBitmap = 0;

        // Lấy tất cả file trong folder
        File[] files = folder.listFiles();
        if (files == null) files = new File[0];

        for (int i = 1; i <= 46; i++) {
            Bitmap bitmap = null;
            String targetName = "shime" + i + ".png";

            // Tìm file khớp không phân biệt chữ hoa/chữ thường
            for (File f : files) {
                if (f.getName().equalsIgnoreCase(targetName)) {
                    bitmap = BitmapUtil.getBitmapFromFile(f);
                    validBitmap++;
                    break;
                }
            }

            // Nếu không tìm thấy thì tạo bitmap trong suốt
            if (bitmap == null) {
                bitmap = BitmapUtil.createTransparentBitmap(128, 128);
            }

            bitmaps.add(bitmap);
        }

        if (validBitmap > 10) {
            ShimejiDAO.getInstance().insertMascotBitmaps(mascotID, bitmaps);
            return ShimejiDAO.getInstance().checkShimejiDownloaded(mascotID);
        }

        return false;
    }


    private static void runOnUiThread(Runnable r) {
        new Handler(Looper.getMainLooper()).post(r);
    }
}
