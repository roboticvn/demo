package com.aquarius.anime.shimeji.lib.mascot;

public class MascotConfig {
    public static final int UNLOCK = 0;
    public static final int LOCK = 1;
    public static final int NOT_EXIST = -1;
    public static final int RUN_ON_SCREEN = 0;
    public static final int SHOW_DETAIL = 3;
    public static final int ONLY_SHOW_SPECIAL1 = 1;
    public static final int ONLY_SHOW_SPECIAL2 = 2;
    public int mode;
    public int showSpecial; //1-show, 0-not show, -1-not exist
    public int showSpecial2; //1-show, 0-not show, -1-not exist

    public MascotConfig() {
        mode = RUN_ON_SCREEN;
        showSpecial = NOT_EXIST;
        showSpecial2 = NOT_EXIST;
    }

    public MascotConfig(int mode, int showSpecial, int showSpecial2) {
        this.mode = mode;
        this.showSpecial = showSpecial;
        this.showSpecial2 = showSpecial2;
    }
}
