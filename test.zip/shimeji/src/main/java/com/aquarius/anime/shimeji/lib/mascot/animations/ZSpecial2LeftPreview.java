package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class ZSpecial2LeftPreview extends Special {
    public ZSpecial2LeftPreview(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(41, 0, 0, 10));
        arrayList.add(new Sprite(42, 0, 0, 4));
        arrayList.add(new Sprite(43, 0, 0, 4));
        arrayList.add(new Sprite(44, 0, 0, 10));
        arrayList.add(new Sprite(45, 0, 0, 20));
        arrayList.add(new Sprite(44, 0, 0, 10));
        arrayList.add(new Sprite(43, 0, 0, 4));
        arrayList.add(new Sprite(42, 0, 0, 4));
        arrayList.add(new Sprite(41, 0, 0, 10));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new ZSpecial2LeftPreview(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.LEFT;
    }

}
