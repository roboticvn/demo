package com.aquarius.anime.shimeji.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.custom.glide.DecryptImageModelLoader;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.InternetConnectionUtil;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.api.ShimejiApi;
import com.aquarius.anime.shimeji.background.ShimejiDownloader;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ItemShimejiBinding;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.model.ShimejiMap;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class ShimejiAdapter extends RecyclerView.Adapter<ShimejiAdapter.ViewHolder> implements Filterable {
    private final String TAG = getClass().getSimpleName();

    public interface Listener {
        void OnItemClickListener(int position, Shimeji shimeji, ShimejiMap map);
    }

    private ArrayList<Shimeji> mShimeji;
    private ArrayList<Shimeji> mShimejiFiltered = new ArrayList<>();
    private Listener mListener;


    public ShimejiAdapter(ArrayList<Shimeji> shimejis, Listener listener) {
        this.mShimeji = shimejis;
        this.mListener = listener;
        this.mShimejiFiltered = shimejis;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    mShimejiFiltered = mShimeji;
                } else {
                    ArrayList<Shimeji> filteredList = new ArrayList<>();
                    for (Shimeji shimeji : mShimeji) {
                        if (shimeji.getName().replaceAll("_", "\\s+").toLowerCase().contains(charString.toLowerCase())
                                || shimeji.getCategories().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(shimeji);
                        }
                    }

                    mShimejiFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mShimejiFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mShimejiFiltered = (ArrayList<Shimeji>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemShimejiBinding binding = ItemShimejiBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new ShimejiAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.bind(i);
    }

    @Override
    public int getItemCount() {
        return mShimejiFiltered.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ItemShimejiBinding binding;

        public ViewHolder(ItemShimejiBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        public void bind(int position) {
            final Shimeji shimeji = mShimejiFiltered.get(position);
            ShimejiMap map = ShimejiDAO.getInstance().getShimejiMapByID(shimeji.getMascotID());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.OnItemClickListener(position, shimeji, map);
                }
            });

            SimpleDateFormat sdf = new SimpleDateFormat(Constants.FORMAT_DATE);
            Date current = new Date();
            Date beforeDay = new Date(current.getTime() - (4 * 24 * 3600 * 1000)); //4 day
            Date strDate = null;
            try {
                strDate = sdf.parse(shimeji.getCreated());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            if (strDate != null) {
                LogUtil.d(TAG, "item_created: " + sdf.format(strDate) + " " + sdf.format(beforeDay));
            }
            if (strDate != null && strDate.after(beforeDay)) {
                LogUtil.d(TAG, "check_label_new");
                binding.labelNew.setVisibility(View.VISIBLE);
            } else {
                LogUtil.d(TAG, "check_label_no_new");
                binding.labelNew.setVisibility(View.GONE);
            }

            if (shimeji.getLock() == MascotConfig.LOCK) {
                binding.btnUnlock.setVisibility(View.VISIBLE);
                binding.btnDowload.setVisibility(View.GONE);
            } else {
                binding.btnUnlock.setVisibility(View.GONE);
                if (ShimejiDAO.getInstance().checkShimejiDownloaded(shimeji.getMascotID())) {
                    binding.btnDowload.setVisibility(View.GONE);
                } else {
                    binding.btnDowload.setVisibility(View.VISIBLE);
                }
            }

            LogUtil.d(TAG, shimeji.getName() + "    " + shimeji.getThumb());
            //binding.itemRootView.setBackgroundColor(Color.parseColor(Constants.COLORS[position % 5]));

            if (map != null) {
                binding.searchOnView.setVisibility(View.VISIBLE);
                binding.btnUnlock.setVisibility(View.GONE);
                binding.btnDowload.setVisibility(View.GONE);
            } else {
                binding.searchOnView.setVisibility(View.GONE);
            }

            String name = shimeji.getName().split("\\.")[0].replaceAll("_", " ");
            binding.tvName.setText(name);
            binding.tvCategory.setText(shimeji.getCategories());

//            Glide.with(itemView.getContext()).load(shimeji.getThumb()).listener(new RequestListener<Drawable>() {
//                @Override
//                public boolean onLoadFailed(GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
//                    return false;
//                }
//
//                @Override
//                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                    binding.prg.setVisibility(View.GONE);
//                    binding.img.setVisibility(View.VISIBLE);
//                    return false;
//                }
//            }).into(binding.img);

            if (shimeji != null && shimeji.getThumb() != null && shimeji.getThumb().contains("http")) {
                String[] parts = shimeji.getThumb().split("/");
                int id = Integer.parseInt(parts[parts.length - 2]); // "1"
                String fileName = parts[parts.length - 1]; // "shime1.png"
                if (ConfigManager.getInstance().isOnlySelfHost()) {
                    loadThumbFromSelfHost(id, fileName, binding.img);
                } else {
                    loadThumbFromGithub(id, fileName, shimeji.getThumb(), binding.img);
                }
            } else {
                loadThumbFromLocal(shimeji.getThumb(), binding.img);
            }

            binding.btnDowload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!InternetConnectionUtil.checkConnection(itemView.getContext())) {
                        Toast.makeText(itemView.getContext(), itemView.getContext().getString(com.aquarius.anime.common.R.string.no_internet), Toast.LENGTH_SHORT).show();
                    }
                    binding.btnDowload.setVisibility(View.GONE);
                    binding.prgDownload.setVisibility(View.VISIBLE);

                    ShimejiDownloader.downloadShimeji(shimeji, new ShimejiDownloader.Listener() {
                        @Override
                        public void onSuccess() {
                            binding.prgDownload.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {
                            binding.prgDownload.setVisibility(View.GONE);
                            binding.btnDowload.setVisibility(View.VISIBLE);
                        }
                    });

                }
            });
        }

        private void loadThumbFromLocal(String thumbPath, ImageView imageView) {
            Glide.with(itemView.getContext())
                    .load(thumbPath)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, @Nullable Object model, @NonNull Target<Drawable> target, boolean isFirstResource) {
                            LogUtil.d(TAG, "onLoadFailed: " + (e != null ? e.getMessage() : "unknown error"));
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(@NonNull Drawable resource, @NonNull Object model, Target<Drawable> target, @NonNull DataSource dataSource, boolean isFirstResource) {
                            LogUtil.d(TAG, "onResourceReady");
                            binding.prg.setVisibility(View.GONE);
                            binding.img.setVisibility(View.VISIBLE);
                            return false;
                        }
                    })
                    .into(imageView);
        }

        private void loadThumbFromSelfHost(int id, String fileName, ImageView imageView) {
            String url = ShimejiApi.getSelfHostShimejiUrl(id, fileName);
            String stableUrl = DecryptImageModelLoader.extractStablePartFromUrl(url);
            GlideUrl glideUrl = new GlideUrl(url) {
                @Override
                public String getCacheKey() {
                    return stableUrl;
                }
            };
            LogUtil.d(TAG, "url: " + url);
            Context context = imageView.getContext();
            if (context instanceof Activity) {
                Activity activity = (Activity) context;
                if (!activity.isDestroyed() && !activity.isFinishing()) {
                    Glide.with((FragmentActivity) activity)
                            .load(glideUrl)
                            .listener(new RequestListener<Drawable>() {
                                @Override
                                public boolean onLoadFailed(@Nullable GlideException e, @Nullable Object model, @NonNull Target<Drawable> target, boolean isFirstResource) {
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(@NonNull Drawable resource, @NonNull Object model, Target<Drawable> target, @NonNull DataSource dataSource, boolean isFirstResource) {
                                    binding.prg.setVisibility(View.GONE);
                                    binding.img.setVisibility(View.VISIBLE);
                                    return false;
                                }
                            })
                            .into(imageView);
                }
            }
        }

        private void loadThumbFromGithub(int id, String fileName, String originalUrl, ImageView imageView) {
            LogUtil.d(TAG, "url: " + originalUrl);
            String stableUrl = DecryptImageModelLoader.extractStablePartFromUrl(originalUrl);
            GlideUrl glideUrl = new GlideUrl(originalUrl) {
                @Override
                public String getCacheKey() {
                    return stableUrl;
                }
            };
            Glide.with(itemView.getContext())
                    .load(glideUrl)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, @Nullable Object model, @NonNull Target<Drawable> target, boolean isFirstResource) {
                            LogUtil.d(TAG, "onLoadFailed: " + (e != null ? e.getMessage() : "unknown error"));
                            if (ConfigManager.getInstance().isFallbackSelfHost()) {
                                imageView.post(() -> {
                                    loadThumbFromSelfHost(id, fileName, imageView);
                                });

                            }
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(@NonNull Drawable resource, @NonNull Object model, Target<Drawable> target, @NonNull DataSource dataSource, boolean isFirstResource) {
                            LogUtil.d(TAG, "onResourceReady");
                            binding.prg.setVisibility(View.GONE);
                            binding.img.setVisibility(View.VISIBLE);
                            return false;
                        }
                    })
                    .into(imageView);
        }
    }

}
