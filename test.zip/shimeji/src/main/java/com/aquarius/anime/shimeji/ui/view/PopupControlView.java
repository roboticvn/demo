package com.aquarius.anime.shimeji.ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.aquarius.anime.shimeji.R;

public class PopupControlView extends LinearLayout {
    public PopupControlView(Context context) {
        super(context);
        init(context);
    }

    public PopupControlView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PopupControlView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    public PopupControlView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    public interface Listener {
        void OnHome();

        void OnSetting();
    }

    private Listener mListener;

    public void setListener(Listener listener) {
        mListener = listener;
    }

    public void init(Context context) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View layout = inflater.inflate(R.layout.popup_control, this, true);
        LinearLayout btnHome = layout.findViewById(R.id.btn_home);
        LinearLayout btnSetting = layout.findViewById(R.id.btn_setting);
        btnHome.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) mListener.OnHome();
            }
        });
        btnSetting.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListener != null) mListener.OnSetting();
            }
        });
    }
}
