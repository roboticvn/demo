package com.aquarius.anime.shimeji.ui.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.event.AppEvents;
import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.common.ui.activity.PremiumActivity;
import com.aquarius.anime.common.ui.dialog.DialogManager;
import com.aquarius.anime.common.util.CommonSettingUtil;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityEditShimejiBinding;
import com.aquarius.anime.shimeji.lib.DetailShimejiService;
import com.aquarius.anime.shimeji.lib.ShimejiService;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.ui.dialog.UnlockSpecialActionDialog;
import com.aquarius.anime.shimeji.util.ShimejiConstants;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;


public class EditShimejiActivity extends BaseActivity {
    private final String TAG = getClass().getSimpleName();

    public void cancel() {
        finish();
    }

    public void removeShimeji() {
        ShimejiDAO.getInstance().removeActiveShimeji(mActiveShimeji);
        Intent intent = new Intent(this, ShimejiService.class);
        intent.setAction(ShimejiService.ACTION_REMOVE);
        intent.putExtra(ShimejiConstants.EXTRA_ACTIVE_ID, mActiveShimeji.getId());
        startService(intent);
        finish();
    }

    public void saveShimeji() {
        ShimejiDAO.getInstance().updateActiveShimeji(mActiveShimeji);
        Intent intent = new Intent(this, ShimejiService.class);
        intent.setAction(ShimejiService.ACTION_START);
        startService(intent);
        finish();
    }

    public void showSpecialPreview() {
        if (mBoundService != null) {
            mBoundService.removeMascotView();
            DialogManager.getInstance().showDialog(getSupportFragmentManager(), new UnlockSpecialActionDialog(mShimeji.getMascotID(), MascotConfig.ONLY_SHOW_SPECIAL2, new UnlockSpecialActionDialog.Listener() {
                @Override
                public void OnPremium() {
                    Intent intent = new Intent(EditShimejiActivity.this, PremiumActivity.class);
                    startActivity(intent);
                }

                @Override
                public void OnUnlockByCoin() {
                    ShimejiDAO.getInstance().unlockSpecial(mShimeji.getMascotID());
                    binding.btnLockSpecial.setVisibility(View.GONE);
                    config.showSpecial = MascotConfig.UNLOCK;
                    mShimeji.setSpecialLock(MascotConfig.UNLOCK);
                    ShimejiDAO.getInstance().updateShimeji(mShimeji);
                    mBoundService.initMascotViews(mActiveShimeji, config);
                    ConfigManager.getInstance().minusCoins(ShimejiConstants.SHIMEJI_SPECIAL_ACTION_UNLOCK_COINS);
                    refreshSpecialActionViews();
                }

                @Override
                public void OnCancel() {
                    mBoundService.initMascotViews(mActiveShimeji, config);
                }
            }), "unlock_special_action_1");
        }
    }

    public void showSpecial2Preview() {
        if (mBoundService != null) {
            mBoundService.removeMascotView();
            DialogManager.getInstance().showDialog(getSupportFragmentManager(), new UnlockSpecialActionDialog(mShimeji.getMascotID(), MascotConfig.ONLY_SHOW_SPECIAL2, new UnlockSpecialActionDialog.Listener() {
                @Override
                public void OnPremium() {
                    Intent intent = new Intent(EditShimejiActivity.this, PremiumActivity.class);
                    startActivity(intent);
                }

                @Override
                public void OnUnlockByCoin() {
                    ShimejiDAO.getInstance().unlockSpecial2(mShimeji.getMascotID());
                    binding.btnLockSpecial2.setVisibility(View.GONE);
                    config.showSpecial2 = MascotConfig.UNLOCK;
                    mShimeji.setSpecial2Lock(MascotConfig.UNLOCK);
                    ShimejiDAO.getInstance().updateShimeji(mShimeji);
                    mBoundService.initMascotViews(mActiveShimeji, config);
                    ConfigManager.getInstance().minusCoins(ShimejiConstants.SHIMEJI_SPECIAL_ACTION_UNLOCK_COINS);
                    refreshSpecialActionViews();
                }

                @Override
                public void OnCancel() {
                    mBoundService.initMascotViews(mActiveShimeji, config);
                }
            }), "unlock_special_action_2");
        }
    }


    private Shimeji mShimeji;
    private ActiveShimeji mActiveShimeji;
    private MascotConfig config = new MascotConfig();
    private boolean mIsBound;

    private DetailShimejiService mBoundService;
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder service) {
            LogUtil.d(TAG, "onServiceConnected");
            mBoundService = ((DetailShimejiService.LocalBinder) service).getService();
            mBoundService.initMascotViews(mActiveShimeji, config);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    ActivityEditShimejiBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditShimejiBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancel();
            }
        });
        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancel();
            }
        });
        binding.btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeShimeji();
            }
        });
        binding.btnSpecial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSpecialPreview();
            }
        });
        binding.btnSpecial2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSpecial2Preview();
            }
        });
        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveShimeji();
            }
        });
        //RequestOptions options = new RequestOptions().centerCrop();
        //Glide.with(this).load(R.drawable.scene).apply(options).into(binding.imageScene);
        try {
            mActiveShimeji = ShimejiDAO.getInstance().getActiveShimejiByID(getIntent()
                    .getIntExtra(ShimejiConstants.EXTRA_ACTIVE_ID, 0));
            mShimeji = ShimejiDAO.getInstance().getShimejiByID(mActiveShimeji.getMascotID());

            config.mode = MascotConfig.SHOW_DETAIL;
            config.showSpecial = mShimeji.getSpecialLock();
            config.showSpecial2 = mShimeji.getSpecial2Lock();
            LogUtil.d(TAG, "showSpecial: " + mShimeji.getName() + " " + config.showSpecial);
            refreshSpecialActionViews();
            if (config.showSpecial == MascotConfig.NOT_EXIST)
                (findViewById(R.id.btn_special)).setVisibility(View.GONE);
            else if (config.showSpecial == MascotConfig.LOCK)
                (findViewById(R.id.btn_lock_special)).setVisibility(View.VISIBLE);
            else if (config.showSpecial == MascotConfig.UNLOCK)
                (findViewById(R.id.btn_lock_special)).setVisibility(View.GONE);

            if (config.showSpecial2 == MascotConfig.NOT_EXIST)
                (findViewById(R.id.btn_special2)).setVisibility(View.GONE);
            else if (config.showSpecial2 == MascotConfig.LOCK)
                (findViewById(R.id.btn_lock_special2)).setVisibility(View.VISIBLE);
            else if (config.showSpecial == MascotConfig.UNLOCK)
                (findViewById(R.id.btn_lock_special2)).setVisibility(View.GONE);

            Glide.with(this).load(mShimeji.getThumb()).into(binding.imageThumb);
            binding.tvName.setText(mShimeji.getName());
            binding.tvCategory.setText(mShimeji.getCategories());
            Glide.with(this).load(ShimejiDAO.getInstance().getSpecialThumb(mShimeji.getMascotID())).into(binding.imgSpecialThumb);
            Glide.with(this).load(ShimejiDAO.getInstance().getSpecial2Thumb(mShimeji.getMascotID())).into(binding.imgSpecial2Thumb);

            binding.skbSize.setProgress(((int) (mActiveShimeji.getSize() * 10.0d)) - 9);
            binding.skbSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    if (b) {
                        if (i == 0) {
                            seekBar.setProgress(1);
                        }
                        double d = (double) (i + 9);
                        Double.isNaN(d);
                        mActiveShimeji.setSize(d / 10.0d);
                        try {
                            mBoundService.initMascotViews(mActiveShimeji, config);
                        } catch (Exception e) {

                        }
                        return;
                    }
                    mActiveShimeji.setSize(1.0d);
                    try {
                        mBoundService.initMascotViews(mActiveShimeji, config);
                    } catch (Exception e) {

                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

            binding.skbSpeed.setProgress(((int) (mActiveShimeji.getSpeed() * 10.0d)) - 9);
            binding.skbSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    if (b) {
                        if (i == 0) {
                            seekBar.setProgress(1);
                        }
                        double d = (double) (i + 9);
                        Double.isNaN(d);
                        mActiveShimeji.setSpeed(d / 10.0d);
                        try {
                            mBoundService.updateSpeedMascotView(mActiveShimeji);
                        } catch (Exception e) {

                        }
                        return;
                    }
                    mActiveShimeji.setSpeed(1.0d);
                    try {
                        mBoundService.updateSpeedMascotView(mActiveShimeji);
                    } catch (Exception e) {

                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });

            Intent intent = new Intent(this, DetailShimejiService.class);
            //intent.putExtra(Constants.EXTRA_ACTIVE_SHIMEJI, activeShimeji);
            startService(intent);
            doBindService();
        } catch (Exception e) {
            Toast.makeText(this, "Unknown error! Try again later", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshSpecialActionViews() {
        if (mShimeji.getSpecialLock() == MascotConfig.UNLOCK && mShimeji.getSpecial2Lock() == MascotConfig.UNLOCK) {
            binding.rowSpecialActions.setVisibility(View.GONE);
            binding.specialActionDecorator.setVisibility(View.GONE);
        } else {
            if (mShimeji.getSpecialLock() == MascotConfig.UNLOCK) {
                binding.btnSpecial.setVisibility(View.GONE);
            } else {
                binding.btnSpecial.setVisibility(View.VISIBLE);
            }
            if (mShimeji.getSpecial2Lock() == MascotConfig.UNLOCK) {
                binding.btnSpecial2.setVisibility(View.GONE);
            } else {
                binding.btnSpecial2.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ConfigManager.getInstance().isVip()) binding.tvCoin.setVisibility(View.GONE);
        else binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        binding.tvCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().goToPremium(EditShimejiActivity.this);
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause");
        doUnbindService();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDataEvent(AppEvents.DataEvent event) {
        switch (event.type) {
            case COIN_CHANGED:
                LogUtil.d(TAG, "COIN_CHANGED event");
                binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
                break;
        }
    }

    void doBindService() {
        // Establish a connection with the service.  We use an explicit
        // class name because we want a specific service implementation that
        // we know will be running in our own process (and thus won't be
        // supporting component replacement by other applications).
        bindService(new Intent(this,
                DetailShimejiService.class), mConnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
    }

    void doUnbindService() {
        if (mIsBound) {
            // Detach our existing connection.
            unbindService(mConnection);
            mIsBound = false;
            Intent intent = new Intent(this, DetailShimejiService.class);
            stopService(intent);
        }
    }
}