package com.aquarius.anime.shimeji.model;

public class ShimejiMap {
    private int id;
    private String url;

    public ShimejiMap() {
    }

    public ShimejiMap(int id, String url) {
        this.id = id;
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public ShimejiMap setId(int id) {
        this.id = id;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public ShimejiMap setUrl(String url) {
        this.url = url;
        return this;
    }
}
