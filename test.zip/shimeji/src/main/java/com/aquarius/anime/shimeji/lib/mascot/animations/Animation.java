package com.aquarius.anime.shimeji.lib.mascot.animations;


import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.List;
import java.util.Random;

public abstract class Animation {
    MascotConfig config;
    private int frameNumber = 0;
    private int lastSpriteFrame = 0;
    private int maxDuration;
    boolean nextAnimationRequested;
    Random random = new Random();
    private int spriteIndex = 0;
    private List<Sprite> sprites = getSprites();

//    Animation() {
//        maxDuration = getMaxDuration();
//    }

    Animation(MascotConfig config) {
        this.config = config;
        maxDuration = getMaxDuration();
    }

    /* access modifiers changed from: package-private */
    public enum Direction {
        LEFT,
        RIGHT
    }

    public abstract void checkBorders(boolean z, boolean z2, boolean z3, boolean z4);

    /* access modifiers changed from: package-private */
    public abstract Direction getDirection();

    /* access modifiers changed from: package-private */
    public abstract boolean getIsOneShot();

    /* access modifiers changed from: package-private */
    public int getMaxDuration() {
        return 0;
    }

    /* access modifiers changed from: package-private */
    public abstract Animation getNextAnimation();

    /* access modifiers changed from: package-private */
    public Animation getOptionalAnimation() {
        return null;
    }

    /* access modifiers changed from: package-private */
    public abstract List<Sprite> getSprites();


    public Animation frameTick() {
        int i = this.frameNumber + 1;
        this.frameNumber = i;
        if (this.nextAnimationRequested) {
            return getNextAnimation();
        }
        int i2 = this.maxDuration;
        if (i2 <= 0 || i < i2 || getOptionalAnimation() == null) {
            return (this.frameNumber <= this.lastSpriteFrame + this.sprites.get(this.spriteIndex).duration || !updateSprite()) ? this : getNextAnimation();
        }
        return getOptionalAnimation();
    }

    private boolean updateSprite() {
        this.lastSpriteFrame = this.frameNumber;
        if (this.spriteIndex + 1 >= this.sprites.size()) {
            boolean isOneShot = getIsOneShot();
            this.spriteIndex = 0;
            return isOneShot;
        }
        this.spriteIndex++;
        return false;
    }

    public int getXVelocity() {
        return this.sprites.get(this.spriteIndex).xVelocity;
    }

    public int getYVelocity() {
        return this.sprites.get(this.spriteIndex).yVelocity;
    }

    public int getSpriteIdentifier() {
        return this.sprites.get(this.spriteIndex).index;
    }

    public boolean isFacingLeft() {
        return getDirection() == Direction.LEFT;
    }
}
