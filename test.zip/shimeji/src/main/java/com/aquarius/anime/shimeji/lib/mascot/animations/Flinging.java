package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class Flinging extends Animation {
    private Direction direction;
    private boolean grabBottom;
    private boolean grabLeft;
    private boolean grabRight;
    private boolean grabTop;

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    public Flinging(int i, MascotConfig config) {
        super(config);
        this.direction = i < 0 ? Direction.LEFT : Direction.RIGHT;
    }

    public Animation drop() {
        return getNextAnimation();
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(7, 0, 0, 250));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        if (this.grabLeft) {
            return new ClimbLeft(config);
        }
        if (this.grabRight) {
            return new ClimbRight(config);
        }
        if (this.grabTop) {
            return this.direction == Direction.LEFT ? new ClimbCeilingLeft(config) : new ClimbCeilingRight(config);
        }
        if (this.grabBottom) {
            return new Bounce(this.direction, config);
        }
        return new Falling(this.direction, config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return this.direction;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.grabTop = z;
        this.grabBottom = z2;
        this.grabLeft = z3;
        this.grabRight = z4;
        this.nextAnimationRequested = z || z2 || z3 || z4;
    }
}
