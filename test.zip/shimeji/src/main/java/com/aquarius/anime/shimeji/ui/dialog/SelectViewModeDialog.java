package com.aquarius.anime.shimeji.ui.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.aquarius.anime.common.R;
import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.ui.dialog.BaseDialogFragment;
import com.aquarius.anime.shimeji.databinding.DialogSelectViewModeBinding;


public class SelectViewModeDialog extends BaseDialogFragment {

    public interface Listener {
        void OnSelectCategoriesMode(boolean enable);
    }

    private Listener mListener;

    public SelectViewModeDialog() {
    }

    public SelectViewModeDialog(Listener listener) {
        mListener = listener;
    }

    DialogSelectViewModeBinding binding;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), R.style.RoundDialogTheme);
        binding = DialogSelectViewModeBinding.inflate(LayoutInflater.from(getContext()));


        if (ConfigManager.getInstance().isViewModeCategories()) {
            binding.rdbCategories.setChecked(true);
        } else {
            binding.rdbCharacteres.setChecked(true);
        }

        binding.rdbCategories.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mListener.OnSelectCategoriesMode(true);
                    dismiss();
                }
            }
        });

        binding.rdbCharacteres.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mListener.OnSelectCategoriesMode(false);
                    dismiss();
                }
            }
        });
        binding.btnCancel.setOnClickListener(v -> dismiss());
        dialog.setContentView(binding.getRoot());

        return dialog;
    }
}

