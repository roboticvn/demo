package com.aquarius.anime.shimeji.lib.mascot;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Scroller;


import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.util.BitmapUtil;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicLong;

public class MascotView extends SurfaceView implements SurfaceHolder.Callback {
    private final String TAG = getClass().getSimpleName();
    static final AtomicLong NEXT_ID = new AtomicLong(0);
    private final Runnable drawRunner = new Runnable() {
        /* class com.digitalcosmos.shimeji.mascot.MascotView.AnonymousClass1 */

        public void run() {
            try {
                MascotView.this.draw();
            }catch (Exception e){
                
            }
        }
    };
    private MascotEventNotifier eventNotifier;
    Matrix flipHorizontalMatrix = new Matrix();
    private GestureDetector gestureDetector;
    public GestureDetector.OnGestureListener gestureListener = new GestureDetector.SimpleOnGestureListener() {
        /* class com.digitalcosmos.shimeji.mascot.MascotView.AnonymousClass2 */
        private int initialX;
        private int initialY;

        public boolean onDoubleTap(MotionEvent motionEvent) {
            LogUtil.d(TAG, "Double tap on mascot: " + MascotView.this.mascotId);
            clickListener.OnDoubleClick();
            return true;
        }

        public boolean onDown(MotionEvent motionEvent) {
            if (MascotView.this.mascot == null) {
                return false;
            }
            this.initialX = MascotView.this.mascot.getX();
            this.initialY = MascotView.this.mascot.getY();
            return false;
        }

        public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
            LogUtil.d(TAG, "Single tap on mascot: " + MascotView.this.mascotId);
            clickListener.OnSingleClick();
            return super.onSingleTapConfirmed(motionEvent);
        }

        public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            int i = (int) f;
            int i2 = (int) f2;
            MascotView.this.mascot.setFlingSpeed(i, i2);
            MascotView.this.scroller.fling(MascotView.this.mascot.getX(), MascotView.this.mascot.getY(), i, i2, MascotView.this.playground.getLeft() - 100, MascotView.this.playground.getRight() + 100, MascotView.this.playground.getTop() - 100, MascotView.this.playground.getBottom() + 100);
            LogUtil.d(TAG, "Fling on mascot: " + MascotView.this.mascotId);
            return true;
        }

        public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2) {
            MascotView.this.drag(this.initialX + ((int) (motionEvent2.getRawX() - motionEvent.getRawX())), this.initialY + ((int) (motionEvent2.getRawY() - motionEvent.getRawY())));
            return false;
        }
    };
    private final Handler handler = new Handler();
    public int height;
    final long id = NEXT_ID.getAndIncrement();
    public boolean isAnimationRunning = true;
    public boolean isHidden = false;
    private Context mContext;
    private Mascot mascot;
    public int mascotId;
    private Paint paint;
    Playground playground;
    private Scroller scroller;
    public int width;
    private int activeID;
    private MascotClickListener clickListener;

    public interface MascotEventNotifier {
        void hideMascot();

        void showMascot();
    }

    public interface MascotClickListener{
        void OnDoubleClick();
        void OnSingleClick();
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    public long getUniqueId() {
        return this.id;
    }

    public MascotView(Context context, ActiveShimeji activeShimeji, MascotConfig config, MascotClickListener listener) {
        super(context);
        clickListener = listener;
        this.mascotId = activeShimeji.getMascotID();
        this.activeID = activeShimeji.getId();
        this.mContext = context;
        Paint paint2 = new Paint();
        this.paint = paint2;
        paint2.setAntiAlias(true);
        setBackgroundColor(0);
        setZOrderOnTop(true);
        HashMap<Integer, Bitmap> mascotAssets = ShimejiDAO.getInstance().getMascotAssets(activeShimeji.getMascotID(), SpriteUtil.getUsedSprites());
        Sprites spritesById = BitmapUtil.resizeSprites(new Sprites(mascotAssets), activeShimeji.getSize());
        Log.i("Minato", "size_: " + spritesById.size());
        this.height = spritesById.getHeight();
        this.width = spritesById.getWidth();
        this.mascot = new Mascot();
        Playground playground2 = new Playground(this.mContext, ConfigManager.getInstance().isNavigationBarDetect());
        this.playground = playground2;
        this.mascot.initialize(spritesById, activeShimeji.getSpeed(), playground2, config);
        this.mascot.startAnimation();
        getHolder().setFormat(-2);
        getHolder().addCallback(this);
        if (config.mode != MascotConfig.SHOW_DETAIL)
            this.gestureDetector = new GestureDetector(this.mContext, this.gestureListener);
        else
            this.gestureDetector = new GestureDetector(this.mContext, new GestureDetector.SimpleOnGestureListener());
        this.scroller = new Scroller(this.mContext);
    }

    //using for detail shimeji activity
    public MascotView(Context context, ActiveShimeji activeShimeji, MascotConfig config, Playground playground) {
        super(context);
        this.mascotId = activeShimeji.getMascotID();
        this.activeID = activeShimeji.getId();
        this.mContext = context;
        Paint paint2 = new Paint();
        this.paint = paint2;
        paint2.setAntiAlias(true);
        setBackgroundColor(0);
        setZOrderOnTop(true);
        HashMap<Integer, Bitmap> mascotAssets = ShimejiDAO.getInstance().getMascotAssets(activeShimeji.getMascotID(), SpriteUtil.getUsedSprites());
        Sprites spritesById = BitmapUtil.resizeSprites(new Sprites(mascotAssets), activeShimeji.getSize());
        this.height = spritesById.getHeight();
        this.width = spritesById.getWidth();
        this.mascot = new Mascot();
        this.playground = playground;
        this.mascot.initialize(spritesById, activeShimeji.getSpeed(), playground, config);
        this.mascot.startAnimation();
        getHolder().setFormat(-2);
        getHolder().addCallback(this);
        if (config.mode != MascotConfig.SHOW_DETAIL)
            this.gestureDetector = new GestureDetector(this.mContext, this.gestureListener);
        else
            this.gestureDetector = new GestureDetector(this.mContext, new GestureDetector.SimpleOnGestureListener());
        this.scroller = new Scroller(this.mContext);
    }

    public int getActiveID() {
        return activeID;
    }

    public void setMascotEventsListener(MascotEventNotifier mascotEventNotifier) {
        this.eventNotifier = mascotEventNotifier;
    }

    public void pauseAnimation() {
        this.isAnimationRunning = false;
    }

    public void resumeAnimation() {
        this.isAnimationRunning = true;
    }

    public void setSpeedMultiplier(double d) {
        this.mascot.setSpeedMultiplier(d);
    }

    public void endDrag() {
        this.mascot.endDragging();
    }

    public void drag(int i, int i2) {
        this.mascot.drag(i, i2);
    }

    public void notifyLayoutChange(Context context) {
        Playground playground2 = new Playground(context, false);
        this.playground = playground2;
        this.mascot.resetEnvironmentVariables(playground2);
    }

    public float getX() {
        if (this.mascot.isBeingFlung()) {
            if (this.scroller.computeScrollOffset()) {
                this.mascot.fling(this.scroller.getCurrX(), this.scroller.getCurrY());
            } else {
                this.mascot.endFlinging();
            }
        }
        return (float) this.mascot.getX();
    }

    public float getY() {
        return (float) this.mascot.getY();
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        this.handler.post(this.drawRunner);
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        this.handler.removeCallbacks(this.drawRunner);
    }

    public void draw() {
        Canvas lockCanvas;
        if (this.isAnimationRunning && (lockCanvas = getHolder().lockCanvas()) != null) {
            lockCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
            Bitmap frameBitmap = this.mascot.getFrameBitmap();
            this.height = frameBitmap.getHeight();
            this.width = frameBitmap.getWidth();
            if (this.mascot.isFacingLeft) {
                lockCanvas.drawBitmap(frameBitmap, 0.0f, 0.0f, this.paint);
            } else {
                this.flipHorizontalMatrix.setScale(-1.0f, 1.0f);
                this.flipHorizontalMatrix.postTranslate((float) this.width, 0.0f);
                lockCanvas.drawBitmap(frameBitmap, this.flipHorizontalMatrix, this.paint);
            }
            getHolder().unlockCanvasAndPost(lockCanvas);
        }
        this.handler.removeCallbacks(this.drawRunner);
        this.handler.postDelayed(this.drawRunner, 16);
    }

    public boolean performClick() {
        return super.performClick();
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        super.dispatchTouchEvent(motionEvent);
        performClick();
        if (motionEvent.getAction() == 1) {
            endDrag();
        }
        return this.gestureDetector.onTouchEvent(motionEvent);
    }
}