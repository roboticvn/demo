package com.aquarius.anime.shimeji.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Shimeji implements Parcelable {
    private int mascotID;
    private String name;
    private String categories;
    private String thumb;
    private String url;
    private String author;
    private int lock;
    private int specialLock;
    private int special2Lock;
    private String created;

    public Shimeji() {
    }

    public Shimeji(int mascotID, String name, String category, String thumb, String url, String author, int lock, int specialLock, int special2Lock, String created) {
        this.mascotID = mascotID;
        this.name = name;
        this.categories = category;
        this.thumb = thumb;
        this.url = url;
        this.author = author;
        this.lock = lock;
        this.specialLock = specialLock;
        this.special2Lock = special2Lock;
        this.created = created;
    }

    protected Shimeji(Parcel in) {
        mascotID = in.readInt();
        name = in.readString();
        categories = in.readString();
        thumb = in.readString();
        url = in.readString();
        author = in.readString();
        lock = in.readInt();
        specialLock = in.readInt();
        special2Lock = in.readInt();
        created = in.readString();
    }

    public static final Creator<Shimeji> CREATOR = new Creator<Shimeji>() {
        @Override
        public Shimeji createFromParcel(Parcel in) {
            return new Shimeji(in);
        }

        @Override
        public Shimeji[] newArray(int size) {
            return new Shimeji[size];
        }
    };

    public int getMascotID() {
        return mascotID;
    }

    public Shimeji setMascotID(int mascotID) {
        this.mascotID = mascotID;
        return this;
    }

    public String getName() {
        return name;
    }

    public Shimeji setName(String name) {
        this.name = name;
        return this;
    }

    public String getCategories() {
        return categories;
    }

    public Shimeji setCategories(String categories) {
        this.categories = categories;
        return this;
    }

    public String getThumb() {
        return thumb;
    }

    public Shimeji setThumb(String thumb) {
        this.thumb = thumb;
        return this;
    }

    public String getUrl() {
        return url;
    }

    public Shimeji setUrl(String url) {
        this.url = url;
        return this;
    }

    public String getAuthor() {
        return author;
    }

    public Shimeji setAuthor(String author) {
        this.author = author;
        return this;
    }

    public int getLock() {
        return lock;
    }

    public Shimeji setLock(int full_lock) {
        this.lock = full_lock;
        return this;
    }

    public int getSpecialLock() {
        return specialLock;
    }

    public Shimeji setSpecialLock(int special_lock) {
        this.specialLock = special_lock;
        return this;
    }

    public int getSpecial2Lock() {
        return special2Lock;
    }

    public Shimeji setSpecial2Lock(int special2_lock) {
        this.special2Lock = special2_lock;
        return this;
    }

    public String getCreated() {
        return created;
    }

    public Shimeji setCreated(String created) {
        this.created = created;
        return this;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(mascotID);
        parcel.writeString(name);
        parcel.writeString(categories);
        parcel.writeString(thumb);
        parcel.writeString(url);
        parcel.writeString(author);
        parcel.writeInt(lock);
        parcel.writeInt(specialLock);
        parcel.writeInt(special2Lock);
        parcel.writeString(created);
    }
}
