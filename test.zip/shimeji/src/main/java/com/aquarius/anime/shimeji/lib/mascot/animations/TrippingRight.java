package com.aquarius.anime.shimeji.lib.mascot.animations;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

final class TrippingRight extends Tripping {
    TrippingRight(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(18, 8, 0, 8));
        arrayList.add(new Sprite(17, 4, 0, 4));
        arrayList.add(new Sprite(19, 2, 0, 4));
        arrayList.add(new Sprite(19, 0, 0, 10));
        arrayList.add(new Sprite(18, 4, 0, 4));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new WalkRight(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.RIGHT;
    }
}
