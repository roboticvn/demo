package com.aquarius.anime.shimeji.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.database.DBManager;
import com.aquarius.anime.common.sec.SecLib;
import com.aquarius.anime.common.util.AppContextHolder;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.model.Category;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.model.ShimejiMap;
import com.aquarius.anime.shimeji.petcare.PetCareAlertMngr;
import com.aquarius.anime.shimeji.util.BitmapUtil;
import com.aquarius.anime.shimeji.util.ShimejiConfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class ShimejiDAO {
    private final String TAG = getClass().getSimpleName();
    private static ShimejiDAO instance;
    private final SQLiteDatabase db;
    public static final String TABLE_SHIMEJI = "shimeji";
    public static final String TABLE_SHIMEJI_MAP = "shimeji_map";
    public static final String KEY_ID = "id";
    public static final String KEY_MASCOT_ID = "mascot_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_CATEGORIES = "categories";
    public static final String KEY_THUMB = "thumb";
    public static final String KEY_URL = "url";
    public static final String KEY_AUTHOR = "author";
    public static final String KEY_FULL_LOCK = "full_lock";
    public static final String KEY_SPECIAL_LOCK = "special_lock";
    public static final String KEY_SPECIAL2_LOCK = "special2_lock";
    public static final String KEY_CREATED = "created";

    //table active shimeji
    public static final String TABLE_ACTIVE_SHIMEJI = "shimeji_active";
    public static final String KEY_ACTIVE_ID = "active_id";
    public static final String KEY_SIZE = "size";
    public static final String KEY_SPEED = "speed";
    public static final String KEY_TIME_ADDED = "time_added";

    //table bitmaps
    public static final String TABLE_BITMAP = "shimeji_bitmaps";
    public static final String KEY_BITMAP = "bitmap";
    public static final String KEY_FRAME = "frame";

    private ShimejiDAO() {
        db = DBManager.getInstance().getWritableDatabase();
    }

    public static synchronized ShimejiDAO getInstance() {
        if (instance == null) {
            instance = new ShimejiDAO();
        }
        return instance;
    }

    //------------------------ Shimeji table operators -----------------------------------------------//

    public ArrayList<Shimeji> getShimejiList(String categoryName) {
        ArrayList<Shimeji> shimejis = new ArrayList<>();
        Cursor cursor;
        if (categoryName == null) {
            // Lấy tất cả
            cursor = db.query(TABLE_SHIMEJI, null, null,
                    null, null, null, KEY_CREATED + " DESC", null);
        } else {
            // Lọc theo category
            cursor = db.query(TABLE_SHIMEJI, null, KEY_CATEGORIES + " = ?",
                    new String[]{categoryName}, null, null, KEY_CREATED + " DESC", null);
        }
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int mascotID = cursor.getInt(cursor.getColumnIndex(KEY_MASCOT_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(KEY_NAME));
                @SuppressLint("Range") String category = cursor.getString(cursor.getColumnIndex(KEY_CATEGORIES));
                @SuppressLint("Range") String thumb = SecLib.decrypt(cursor.getString(cursor.getColumnIndex(KEY_THUMB)));
                @SuppressLint("Range") String url = SecLib.decrypt(cursor.getString(cursor.getColumnIndex(KEY_URL)));
                @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex(KEY_AUTHOR));
                @SuppressLint("Range") int lock = cursor.getInt(cursor.getColumnIndex(KEY_FULL_LOCK));
                @SuppressLint("Range") int specialLock = cursor.getInt(cursor.getColumnIndex(KEY_SPECIAL_LOCK));
                @SuppressLint("Range") int special2Lock = cursor.getInt(cursor.getColumnIndex(KEY_SPECIAL2_LOCK));
                if (ConfigManager.getInstance().isVip()) {
                    lock = MascotConfig.UNLOCK;
                    specialLock = MascotConfig.UNLOCK;
                    special2Lock = MascotConfig.UNLOCK;
                }
                @SuppressLint("Range") String created = cursor.getString(cursor.getColumnIndex(KEY_CREATED));

                Shimeji shimeji = new Shimeji().setMascotID(mascotID)
                        .setName(name)
                        .setCategories(category)
                        .setThumb(thumb)
                        .setUrl(url)
                        .setAuthor(author)
                        .setLock(lock)
                        .setSpecialLock(specialLock)
                        .setSpecial2Lock(special2Lock)
                        .setCreated(created);
                shimejis.add(shimeji);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return shimejis;
    }

    public int countShimejiInCategory(String categoryName) {
        int count = 0;
        Cursor cursor = db.query(TABLE_SHIMEJI, null, KEY_CATEGORIES + " = ?", new String[]{categoryName}, null, null, null);
        if (cursor != null) {
            count = cursor.getCount(); // chỉ cần lấy số dòng trả về
            cursor.close();
        }
        return count;
    }

    public Shimeji getShimejiByID(int id) {
        Shimeji shimeji = new Shimeji();
        Cursor cursor = db.query(TABLE_SHIMEJI, null,
                KEY_MASCOT_ID + " =?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") int mascotID = cursor.getInt(cursor.getColumnIndex(KEY_MASCOT_ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(KEY_NAME));
                @SuppressLint("Range") String category = cursor.getString(cursor.getColumnIndex(KEY_CATEGORIES));
                @SuppressLint("Range") String thumb = SecLib.decrypt(cursor.getString(cursor.getColumnIndex(KEY_THUMB)));
                @SuppressLint("Range") String url = SecLib.decrypt(cursor.getString(cursor.getColumnIndex(KEY_URL)));
                @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex(KEY_AUTHOR));
                @SuppressLint("Range") int lock = cursor.getInt(cursor.getColumnIndex(KEY_FULL_LOCK));
                @SuppressLint("Range") int specialLock = cursor.getInt(cursor.getColumnIndex(KEY_SPECIAL_LOCK));
                @SuppressLint("Range") int special2Lock = cursor.getInt(cursor.getColumnIndex(KEY_SPECIAL2_LOCK));
                if (ConfigManager.getInstance().isVip()) {
                    lock = MascotConfig.UNLOCK;
                    specialLock = MascotConfig.UNLOCK;
                    special2Lock = MascotConfig.UNLOCK;
                }
                @SuppressLint("Range") String created = cursor.getString(cursor.getColumnIndex(KEY_CREATED));
                if (ConfigManager.getInstance().checkIfItemNotInRemovedList(Constants.AppType.SHIMEJI, String.valueOf(mascotID)))
                    shimeji.setMascotID(mascotID)
                            .setName(name)
                            .setCategories(category)
                            .setThumb(thumb)
                            .setUrl(url)
                            .setAuthor(author)
                            .setLock(lock)
                            .setSpecialLock(specialLock)
                            .setSpecial2Lock(special2Lock)
                            .setCreated(created);
            }
            cursor.close();
            return shimeji;
        }
        cursor.close();
        return null;
    }

    public long insertShimeji(Shimeji shimeji) {
        try {
            //LogUtil.d(TAG, "insertShimeji " + shimeji.getName() + " " + shimeji.getThumb());
            ContentValues values = new ContentValues();
            values.put(KEY_MASCOT_ID, shimeji.getMascotID());
            values.put(KEY_NAME, shimeji.getName());
            values.put(KEY_CATEGORIES, shimeji.getCategories());
            values.put(KEY_THUMB, SecLib.encrypt(shimeji.getThumb()));
            values.put(KEY_URL, SecLib.encrypt(shimeji.getUrl()));
            values.put(KEY_AUTHOR, shimeji.getAuthor());
            values.put(KEY_FULL_LOCK, shimeji.getLock());
            values.put(KEY_SPECIAL_LOCK, shimeji.getSpecialLock());
            values.put(KEY_SPECIAL2_LOCK, shimeji.getSpecial2Lock());
            values.put(KEY_CREATED, shimeji.getCreated());
            //LogUtil.d(TAG, "insertShimeji " + values.getAsString(KEY_THUMB));
            return db.insertWithOnConflict(TABLE_SHIMEJI, null, values, SQLiteDatabase.CONFLICT_IGNORE);
        } catch (Exception e) {

        }
        return -1;
    }

    public long updateShimeji(Shimeji shimeji) {
        try {
            LogUtil.d(TAG, "insertShimeji " + shimeji.getName());
            ContentValues values = new ContentValues();
            values.put(KEY_MASCOT_ID, shimeji.getMascotID());
            values.put(KEY_NAME, shimeji.getName());
            values.put(KEY_CATEGORIES, shimeji.getCategories());
            values.put(KEY_THUMB, SecLib.encrypt(shimeji.getThumb()));
            values.put(KEY_URL, SecLib.encrypt(shimeji.getUrl()));
            values.put(KEY_AUTHOR, shimeji.getAuthor());
            values.put(KEY_FULL_LOCK, shimeji.getLock());
            values.put(KEY_SPECIAL_LOCK, shimeji.getSpecialLock());
            values.put(KEY_SPECIAL2_LOCK, shimeji.getSpecial2Lock());
            values.put(KEY_CREATED, shimeji.getCreated());
            return db.update(TABLE_SHIMEJI, values,
                    KEY_MASCOT_ID + "=?", new String[]{String.valueOf(shimeji.getMascotID())});
        } catch (Exception e) {

        }
        return -1;
    }

    public long countShimejis() {
        try {
            Cursor cursor = db.query(TABLE_SHIMEJI, null, null, null, null, null, null, null);
            if (cursor != null) {
                return cursor.getCount();
            }
        } catch (Exception e) {
            LogUtil.e(TAG, "countShimejis " + e.getMessage());
        }
        return 0;
    }

    public void unlockSpecial(int mascotID) {
        Shimeji shimeji = getShimejiByID(mascotID);
        shimeji.setSpecialLock(MascotConfig.UNLOCK);
        updateShimeji(shimeji);
    }

    public void unlockSpecial2(int mascotID) {
        Shimeji shimeji = getShimejiByID(mascotID);
        shimeji.setSpecial2Lock(MascotConfig.UNLOCK);
        updateShimeji(shimeji);
    }

    public boolean checkShimejiExist(String shimeji) {
        ArrayList<String> names = new ArrayList<>();
        Cursor cursor = db.query(TABLE_SHIMEJI, null, null,
                null, null, null, KEY_CREATED + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(KEY_NAME));
                names.add(name);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        if (names.size() > 0 && names.contains(shimeji)) return true;
        return false;
    }

    public ArrayList<Category> getCategoryList() {
        ArrayList<Category> categories = new ArrayList<>();
        Cursor cursor = db.query(TABLE_SHIMEJI, null, null,
                null, null, null, KEY_CREATED + " DESC", null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(KEY_CATEGORIES));
                @SuppressLint("Range") String thumb = SecLib.decrypt(cursor.getString(cursor.getColumnIndex(KEY_THUMB)));
                int count = countShimejiInCategory(name);
                Category category = new Category(name, thumb, count);
                if (!categories.contains(category)) {
                    categories.add(category);
                }
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return categories;
    }

    //---------------------active shimeji table----------------------------
    public ActiveShimeji getActiveShimejiByID(int id) {
        ActiveShimeji shimeji = new ActiveShimeji();
        Cursor cursor = db.query(TABLE_ACTIVE_SHIMEJI, null,
                KEY_ACTIVE_ID + " =?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") int mascotID = cursor.getInt(cursor.getColumnIndex(KEY_MASCOT_ID));
                @SuppressLint("Range") double size = cursor.getDouble(cursor.getColumnIndex(KEY_SIZE));
                @SuppressLint("Range") double speed = cursor.getDouble(cursor.getColumnIndex(KEY_SPEED));
                @SuppressLint("Range") long timeAdded = cursor.getLong(cursor.getColumnIndex(KEY_TIME_ADDED));
                shimeji.setId(id)
                        .setMascotID(mascotID)
                        .setSize(size)
                        .setSpeed(speed)
                        .setTimeAdded(timeAdded);
            }
            cursor.close();
            return shimeji;
        }
        cursor.close();
        return null;
    }

    public ArrayList<ActiveShimeji> getActiveShimejiList() {
        ArrayList<ActiveShimeji> shimejis = new ArrayList<>();
        Cursor cursor = db.query(TABLE_ACTIVE_SHIMEJI, null,
                null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(KEY_ACTIVE_ID));
                @SuppressLint("Range") int mascotID = cursor.getInt(cursor.getColumnIndex(KEY_MASCOT_ID));
                @SuppressLint("Range") double size = cursor.getDouble(cursor.getColumnIndex(KEY_SIZE));
                @SuppressLint("Range") double speed = cursor.getDouble(cursor.getColumnIndex(KEY_SPEED));
                @SuppressLint("Range") long timeAdded = cursor.getLong(cursor.getColumnIndex(KEY_TIME_ADDED));

                ActiveShimeji shimeji = new ActiveShimeji().setId(id)
                        .setMascotID(mascotID)
                        .setSize(size)
                        .setSpeed(speed)
                        .setTimeAdded(timeAdded);
                shimejis.add(shimeji);
                if (ShimejiConfig.isEnableShimeji())
                    PetCareAlertMngr.getInstance().setAlarms(AppContextHolder.getContext(), shimeji.getId(), shimeji.getTimeAdded());
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return shimejis;
    }

    public long insertActiveShimeji(ActiveShimeji shimeji) {
        try {
            LogUtil.d(TAG, "insertActiveShimeji " + shimeji.getMascotID());
            ContentValues values = new ContentValues();
            values.put(KEY_MASCOT_ID, shimeji.getMascotID());
            values.put(KEY_SIZE, shimeji.getSize());
            values.put(KEY_SPEED, shimeji.getSpeed());
            values.put(KEY_TIME_ADDED, shimeji.getTimeAdded());
            long id = db.insertWithOnConflict(TABLE_ACTIVE_SHIMEJI, null, values, SQLiteDatabase.CONFLICT_IGNORE);
            if (id >= 0 && ShimejiConfig.isEnableShimeji())
                PetCareAlertMngr.getInstance().setAlarms(AppContextHolder.getContext(), (int) id, shimeji.getTimeAdded());
            return id;
        } catch (Exception e) {

        }
        return -1;
    }

    public long updateActiveShimeji(ActiveShimeji shimeji) {
        try {
            LogUtil.d(TAG, "updateActiveShimeji " + shimeji.getMascotID());
            ContentValues values = new ContentValues();
            values.put(KEY_MASCOT_ID, shimeji.getMascotID());
            values.put(KEY_SIZE, shimeji.getSize());
            values.put(KEY_SPEED, shimeji.getSpeed());
            values.put(KEY_TIME_ADDED, shimeji.getTimeAdded());
            return db.update(TABLE_ACTIVE_SHIMEJI, values,
                    KEY_ACTIVE_ID + "=?", new String[]{String.valueOf(shimeji.getId())});
        } catch (Exception e) {

        }
        return -1;
    }


    public long removeActiveShimeji(ActiveShimeji shimeji) {
        try {
            LogUtil.d(TAG, "removeActiveShimeji: " + shimeji.getMascotID());
            long res = db.delete(TABLE_ACTIVE_SHIMEJI, KEY_ACTIVE_ID + " = ?",
                    new String[]{String.valueOf(shimeji.getId())});
            if (res > 0)
                PetCareAlertMngr.getInstance().stopAlarms(AppContextHolder.getContext(), shimeji.getId());
            return res;
        } catch (Exception e) {

        }
        return -1;
    }

    //---------------------active bitmap----------------------------
    public void insertMascotBitmaps(int mascotID, ArrayList<Bitmap> bitmaps) {
        LogUtil.d(TAG, "insertMascotBitmap " + mascotID);
        for (int i = 0; i < bitmaps.size(); i++) {
            insertBitmap(mascotID, i, bitmaps.get(i));
        }
    }

    public long insertBitmap(int mascotID, int frame, Bitmap bitmap) {
        ContentValues values = new ContentValues();
        values.put(KEY_MASCOT_ID, mascotID);
        values.put(KEY_FRAME, frame);
        values.put(KEY_BITMAP, BitmapUtil.bitmapToByteArray(bitmap));
        return db.insertWithOnConflict(TABLE_BITMAP, null, values, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public HashMap<Integer, Bitmap> getMascotAssets(int mascotID, HashSet<Integer> hashSet) {
        HashMap<Integer, Bitmap> hashMap = new HashMap<>();
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =?", new String[]{String.valueOf(mascotID)}, null, null, null, null);
        Integer num = 0;
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                if (hashSet.contains(num)) {
                    Bitmap bmp = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
                    if (bmp != null)
                        hashMap.put(num, bmp);
                }
                num = Integer.valueOf(num.intValue() + 1);
                cursor.moveToNext();
            }
        }
        cursor.close();
        return hashMap;
    }

    public boolean checkShimejiDownloaded(int mascotID) {
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =?", new String[]{String.valueOf(mascotID)}, null, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        if (count > 0) return true;
        return false;
    }

    public Bitmap getSpecialThumb(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(38)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    public Bitmap getSpecial2Thumb(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(41)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    public Bitmap getHungryBitmap(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(20)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    public Bitmap getDirtyBitmap(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(1)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    public Bitmap getBoringBitmap(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(1)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    public Bitmap getFirstPoseBitmap(int mascotID) {
        Bitmap bitmap = null;
        Cursor cursor = db.query(TABLE_BITMAP, null,
                KEY_MASCOT_ID + " =? AND " + KEY_FRAME + " =? ", new String[]{String.valueOf(mascotID), String.valueOf(1)}, null, null, null, null);
        if (cursor.moveToFirst()) {
            bitmap = BitmapUtil.byteArrayToBitmap(cursor.getBlob(cursor.getColumnIndexOrThrow(KEY_BITMAP)));
            if (bitmap == null) bitmap = BitmapUtil.createTransparentBitmap(128, 128);
        }
        cursor.close();
        return bitmap;
    }

    //----------------------- Shimeji Map ------------------------------
    public long insertShimejiMap(ShimejiMap item) {
        try {
            //LogUtil.d(TAG, "insertShimeji " + shimeji.getName() + " " + shimeji.getThumb());
            ContentValues values = new ContentValues();
            values.put(KEY_ID, item.getId());
            values.put(KEY_URL, item.getUrl());
            return db.insertWithOnConflict(TABLE_SHIMEJI_MAP, null, values, SQLiteDatabase.CONFLICT_IGNORE);
        } catch (Exception e) {

        }
        return -1;
    }

    public ArrayList<ShimejiMap> getShimejiMapList() {
        ArrayList<ShimejiMap> items = new ArrayList<>();
        Cursor cursor = db.query(TABLE_SHIMEJI_MAP, null, null,
                null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(KEY_ID));
                @SuppressLint("Range") String url = cursor.getString(cursor.getColumnIndex(KEY_URL));
                ShimejiMap item = new ShimejiMap().setId(id)
                        .setUrl(url);
                items.add(item);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }


    public ShimejiMap getShimejiMapByID(int id) {
        ShimejiMap item = new ShimejiMap();
        Cursor cursor = db.query(TABLE_SHIMEJI_MAP, null,
                KEY_ID + " =?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor.getCount() > 0) {
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String url = cursor.getString(cursor.getColumnIndex(KEY_URL));
                item.setId(id).setUrl(url);
            }
            cursor.close();
            return item;
        }
        cursor.close();
        return null;
    }
}
