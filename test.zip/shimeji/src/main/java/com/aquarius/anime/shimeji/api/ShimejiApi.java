package com.aquarius.anime.shimeji.api;

import androidx.constraintlayout.motion.widget.Debug;

import com.aquarius.anime.common.network.OkHttpProvider;
import com.aquarius.anime.common.sec.SecLib;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.database.ShimejiDAO;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ShimejiApi {

    private static final String TAG = "ShimejiApi";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public static String fetchShimejiJson() {
        long startIndex = Math.max(ShimejiDAO.getInstance().countShimejis(), 0);
        //String url = "https://" + SecLib.getHost() + "/animehub/api/shimeji/get.php?offset=" + startIndex;
        String startDate = "2025-01-03 00:00:00.000";
        String url = "https://" + SecLib.getHost() + "/animehub/api/shimeji/get.php?offset=" + startDate;
        //String url = "https://" + SecLib.getHost() + "/animehub/api/shimeji/get.php";
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("token", SecLib.generateToken());
            jsonObject.put("sign", SecLib.getSignature());
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, jsonObject.toString());
        Response response;
        try {
            OkHttpClient client = OkHttpProvider.getClient();
            Request request = new Request.Builder().url(url).post(body).build();
            response = client.newCall(request).execute();
            String result = response.body().string();
            LogUtil.d(TAG, "API_Response_Shimeji: " + result);
            return result;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    public static String fetchShimejiMapJson() {
        LogUtil.d(TAG, "fetchShimejiMapJson: " + ShimejiDAO.getInstance().getShimejiMapList().size());
        String url = "https://" + SecLib.getHost() + "/animehub/api/shimeji/shimeji_map_get.php";
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("token", SecLib.generateToken());
            jsonObject.put("sign", SecLib.getSignature());
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, jsonObject.toString());
        Response response;
        try {
            OkHttpClient client = OkHttpProvider.getClient();
            Request request = new Request.Builder().url(url).post(body).build();
            response = client.newCall(request).execute();
            String result = response.body().string();
            LogUtil.d(TAG, "API_Response_Shimeji: " + result);
            return result;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    public static String getSelfHostShimejiUrl(int id, String fileName) {
        String token = SecLib.generateToken().replace('+', '-')
                .replace('/', '_')
                .replace('=', '.');
        return "https://" + SecLib.getHost() + "/animehub/api/shimeji/download.php?id=" + id + "&token=" + token + "&sign=" + SecLib.getSignature() + "&file=" + fileName;
    }
}