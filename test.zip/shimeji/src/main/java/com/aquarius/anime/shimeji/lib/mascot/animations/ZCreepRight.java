package com.aquarius.anime.shimeji.lib.mascot.animations;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

final class ZCreepRight extends Creep {
    ZCreepRight(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(19, 0, 0, 28));
        arrayList.add(new Sprite(19, 2, 0, 4));
        arrayList.add(new Sprite(20, 2, 0, 4));
        arrayList.add(new Sprite(20, 1, 0, 4));
        arrayList.add(new Sprite(20, 0, 0, 24));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new ZWalkRight(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.RIGHT;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z4;
    }
}
