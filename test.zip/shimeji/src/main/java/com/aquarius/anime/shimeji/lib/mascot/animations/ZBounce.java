package com.aquarius.anime.shimeji.lib.mascot.animations;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

/* access modifiers changed from: package-private */
public final class ZBounce extends Animation {
    private Direction direction = Direction.RIGHT;

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return true;
    }


    ZBounce(Direction direction2, MascotConfig config) {
        super(config);
        this.direction = direction2;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(17, 0, 0, 8));
        arrayList.add(new Sprite(18, 0, 0, 8));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return this.random.nextBoolean() ? new ZWalkLeft(this.config) : new ZWalkRight(this.config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return this.direction;
    }
}
