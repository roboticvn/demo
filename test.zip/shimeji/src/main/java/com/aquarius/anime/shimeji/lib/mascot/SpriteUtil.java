package com.aquarius.anime.shimeji.lib.mascot;

import java.util.HashSet;

public enum SpriteUtil {
    WALK(new int[]{0, 1, 0, 2}),
    DRAGGING(new int[]{4, 5, 6, 7}),
    JUMP(new int[]{21}),
    FALLING(new int[]{3}),
    CLIMB_WALL(new int[]{11, 12, 13}),
    CLIMB_CEILING(new int[]{22, 23, 24}),
    BOUNCE(new int[]{17, 18}),
    WINK(new int[]{14, 16}),
    SIT(new int[]{10}),
    SIT_DANGLE_LEGS(new int[]{30, 31}),
    SPRAWL(new int[]{20}),
    CREEP(new int[]{19, 20}),
    SIT_LOOK_UP(new int[]{25}),
    TRIP(new int[]{17, 18, 19}),
//    STAND(new int[]{0}),
//    BOUNCE(new int[]{17, 18}),
//    CLIMB_CEILING(new int[]{22, 23, 24}),
//    CLIMB_WALL(new int[]{11, 12, 13}),
//    CREEP(new int[]{19, 20}),
//    DRAGGING(new int[]{4, 5, 6, 7, 8, 9}),
//    FALLING(new int[]{3}),
//    JUMP(new int[]{21}),
//    SIT(new int[]{10}),
//    SIT2(new int[]{10, 14, 15, 16, 25, 26, 27, 28}),
//    SIT_COMFORT(new int[]{29}),
//    SIT_DANGLE_LEGS3(new int[]{31, 32}),
//    SIT_DANGLE_LEGS2(new int[]{30, 31, 32}),
//    SIT_DANGLE_LEGS(new int[]{30, 31}),
//    SIT_LOOK_UP(new int[]{25}),
//    SPECIAL_LEFTNEXT(new int[]{10}),
//    SPECIAL_RIGHTNEXT(new int[]{10}),
    SPECIAL(new int[]{0, 37, 38, 39, 40}),
    SPECIAL2(new int[]{41, 42, 43, 44, 45});
//    SPRAWL(new int[]{20}),
//    SPRAWL2(new int[]{20}),
//    TRIP(new int[]{17, 18, 19}),
//    WALK(new int[]{0, 1, 2}),
//    WINK(new int[]{14, 15, 16});

    int[] values;

    private SpriteUtil(int[] iArr) {
        this.values = iArr;
    }

    public static HashSet<Integer> getUsedSprites() {
        HashSet<Integer> hashSet = new HashSet<>();
        SpriteUtil[] spriteUtilArr = {WALK, DRAGGING, JUMP, FALLING, CLIMB_WALL, CLIMB_CEILING, BOUNCE, WINK, SIT, SIT_LOOK_UP, SIT_DANGLE_LEGS, SPRAWL, CREEP, TRIP, SPECIAL, SPECIAL2};
        for (int i = 0; i < 16; i++) {
            for (int i2 : spriteUtilArr[i].values) {
                hashSet.add(Integer.valueOf(i2));
            }
        }
        return hashSet;
    }
}
