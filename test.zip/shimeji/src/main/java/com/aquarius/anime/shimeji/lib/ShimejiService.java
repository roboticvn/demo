package com.aquarius.anime.shimeji.lib;

import static android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.lib.mascot.MascotView;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.ui.activity.EditShimejiActivity;
import com.aquarius.anime.shimeji.ui.activity.ShimejiSplashActivity;
import com.aquarius.anime.shimeji.ui.view.PopupControlView;
import com.aquarius.anime.shimeji.util.ShimejiConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ShimejiService extends Service {
    private final String TAG = getClass().getSimpleName();
    public static final String ACTION_START = "com.start.shimeji";
    public static final String ACTION_STOP = "com.stop.shimeji";
    public static final String ACTION_REMOVE = "com.remove.shimeji";
    private Handler handler;
    private boolean isShimejiVisible = true;
    private WindowManager mWindowManager;
    private List<MascotView> mascotViews = new ArrayList();
    private BroadcastReceiver screenStatusReceiver = new BroadcastReceiver() {
        /* class com.digitalcosmos.shimeji.displayservice.ShimejiService.AnonymousClass3 */

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.SCREEN_OFF".equals(action)) {
                ShimejiService.this.onScreenOff();
            } else if ("android.intent.action.SCREEN_ON".equals(action)) {
                ShimejiService.this.onScreenOn();
            }
        }
    };
    private HashMap<Long, WindowManager.LayoutParams> viewParams = new HashMap<>();

    public IBinder onBind(Intent intent) {
        return null;
    }

    private Context mContext;

    public void onCreate() {
        super.onCreate();
        mContext = this;
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.handler = new Handler(new Handler.Callback() {
            /* class com.digitalcosmos.shimeji.displayservice.ShimejiService.AnonymousClass1 */

            public boolean handleMessage(Message message) {
                return ShimejiService.this.onHandleMessage(message);
            }
        });
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        if (intent != null && intent.getAction().equalsIgnoreCase(ACTION_REMOVE)) {
            int id = intent.getIntExtra(ShimejiConstants.EXTRA_ACTIVE_ID, 0);
            removeMascotView(id);
        } else {
            try {
                setForegroundNotification(this.isShimejiVisible);
            } catch (Exception e) {
                LogUtil.e(TAG, "FGS not allowed, fallback to normal notification" + e.getMessage());
                setForegroundNotification(false);
                // Thông báo cho user
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(this,
                                getString(R.string.shimeji_cannot_start_fg_service),
                                Toast.LENGTH_LONG).show()
                );
            }
            initMascotViews();
            registerReceiver(this.screenStatusReceiver, new IntentFilter("android.intent.action.SCREEN_OFF"));
            registerReceiver(this.screenStatusReceiver, new IntentFilter("android.intent.action.SCREEN_ON"));
        }
        return START_STICKY;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void toggleShimejiStatus() {
        boolean z = !this.isShimejiVisible;
        this.isShimejiVisible = z;
        setForegroundNotification(z);
        for (MascotView mascotView : this.mascotViews) {
            if (this.isShimejiVisible) {
                add(mascotView);
            } else {
                remove(mascotView);
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void initMascotViews() {
        removeMascotViews();
        WindowManager.LayoutParams layoutParams;
        ArrayList<ActiveShimeji> activeTeamMembers = ShimejiDAO.getInstance().getActiveShimejiList();
        for (ActiveShimeji activeShimeji : activeTeamMembers) {
            if (Build.VERSION.SDK_INT >= 26) {
                layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, 520, PixelFormat.TRANSLUCENT);
            } else {
                layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_PHONE, 520, PixelFormat.TRANSLUCENT);
            }
            layoutParams.gravity = 8388659;
            Shimeji shimeji = ShimejiDAO.getInstance().getShimejiByID(activeShimeji.getMascotID());
            MascotConfig config = new MascotConfig(MascotConfig.RUN_ON_SCREEN,
                    shimeji.getSpecialLock(),
                    shimeji.getSpecial2Lock());
            final MascotView mascotView = new MascotView(this, activeShimeji, config, new MascotView.MascotClickListener() {
                @Override
                public void OnDoubleClick() {
//                    Intent intent = new Intent(mContext, EditShimejiActivity.class);
//                    Intent intent = new Intent(mContext, PetNotiActivity.class);
//                    intent.putExtra(Constants.EXTRA_ACTIVE_ID, activeShimeji.getId());
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                    startActivity(intent);


//                    Intent intent = new Intent(mContext, TransparentStatusPetActivity.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                    intent.putExtra(Constants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.BORING);
//                    intent.putExtra(Constants.EXTRA_MASCOT_ID, shimeji.getMascotID());
//                    startActivity(intent);
                }

                @Override
                public void OnSingleClick() {
                    PopupControlView controlView = new PopupControlView(mContext);
                    controlView.setListener(new PopupControlView.Listener() {
                        @Override
                        public void OnHome() {
                            try {
                                Intent intent = new Intent(mContext, ShimejiSplashActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                mWindowManager.removeViewImmediate(controlView);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void OnSetting() {
                            try {
                                Intent intent = new Intent(mContext, EditShimejiActivity.class);
                                intent.putExtra(ShimejiConstants.EXTRA_ACTIVE_ID, activeShimeji.getId());
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                mWindowManager.removeViewImmediate(controlView);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
                    if (Build.VERSION.SDK_INT >= 26) {
                        layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, 520, PixelFormat.TRANSLUCENT);
                    } else {
                        layoutParams = new WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                                WindowManager.LayoutParams.TYPE_PHONE, 520, PixelFormat.TRANSLUCENT);
                    }
                    layoutParams.gravity = Gravity.CENTER_VERTICAL | Gravity.LEFT;
                    WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                    windowManager.addView(controlView, layoutParams);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                mWindowManager.removeViewImmediate(controlView);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    }, 5000);
                }

            });

            mascotView.setMascotEventsListener(new MascotView.MascotEventNotifier() {
                /* class com.digitalcosmos.shimeji.displayservice.ShimejiService.AnonymousClass2 */

                @Override // com.digitalcosmos.shimeji.mascot.MascotView.MascotEventNotifier
                public void hideMascot() {
                    ShimejiService.this.remove(mascotView);
                }

                @Override // com.digitalcosmos.shimeji.mascot.MascotView.MascotEventNotifier
                public void showMascot() {
                    ShimejiService.this.add(mascotView);
                }
            });
            this.mascotViews.add(mascotView);
            layoutParams.width = mascotView.width;
            layoutParams.height = mascotView.height;
            this.viewParams.put(Long.valueOf(mascotView.getUniqueId()), layoutParams);
            try {
                this.mWindowManager.addView(mascotView, layoutParams);
            } catch (WindowManager.BadTokenException | SecurityException unused) {
                if (Build.VERSION.SDK_INT >= 23) {
                    Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                            Uri.parse("package:" + getPackageName()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Please enable 'Draw on top of other apps' permission for this feature", Toast.LENGTH_LONG).show();
                }
            }
        }

        this.handler.sendEmptyMessage(1);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void removeMascotViews() {
        this.handler.removeMessages(1);
        for (MascotView mascotView : this.mascotViews) {
            if (mascotView != null && mascotView.isShown()) {
                mascotView.pauseAnimation();
                this.mWindowManager.removeViewImmediate(mascotView);
            }
        }
        this.mascotViews.clear();
        this.viewParams.clear();
    }

    private void removeMascotView(int id) {
        for (int i = 0; i < mascotViews.size(); i++) {
            MascotView mascotView = mascotViews.get(i);
            if (mascotView != null && mascotView.getActiveID() == id) {
                mascotView.pauseAnimation();
                this.mWindowManager.removeViewImmediate(mascotView);
                mascotViews.remove(i);
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void add(MascotView mascotView) {
        mascotView.resumeAnimation();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void remove(MascotView mascotView) {
        if (mascotView != null && mascotView.isShown()) {
            mascotView.pauseAnimation();
            mascotView.isHidden = true;
            this.mWindowManager.removeViewImmediate(mascotView);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private boolean onHandleMessage(Message message) {
        if (message.what != 1) {
            return false;
        }
        this.handler.removeMessages(1);
        for (MascotView mascotView : this.mascotViews) {
            if (mascotView.isHidden && mascotView.isAnimationRunning) {
                this.mWindowManager.addView(mascotView, this.viewParams.get(Long.valueOf(mascotView.getUniqueId())));
                mascotView.isHidden = false;
            }
            if (mascotView.isAnimationRunning) {
                WindowManager.LayoutParams layoutParams = this.viewParams.get(Long.valueOf(mascotView.getUniqueId()));
                layoutParams.height = mascotView.height;
                layoutParams.width = mascotView.width;
                layoutParams.x = (int) mascotView.getX();
                layoutParams.y = (int) mascotView.getY();

//                Display display = mWindowManager.getDefaultDisplay();
//                Point size = new Point();
//                display.getSize(size);
//                if(layoutParams.y > size.y/2+200) {
//                    layoutParams.y = size.y/2;
//                }
                try {
                    this.mWindowManager.updateViewLayout(mascotView, layoutParams);
                } catch (Exception e) {

                }
            }
        }
        this.handler.sendEmptyMessageDelayed(1, 16);
        return true;
    }

//    private class PreferenceChangeListener implements SharedPreferences.OnSharedPreferenceChangeListener {
//        private PreferenceChangeListener() {
//        }
//
//        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String str) {
//            if (ShimejiService.this.isShimejiVisible && (str.equals(AppConstants.ACTIVE_MASCOTS_IDS) || str.equals(AppConstants.SIZE_MULTIPLIER))) {
//                ShimejiService.this.removeMascotViews();
//                ShimejiService.this.initMascotViews();
//            } else if (str.equals(AppConstants.ANIMATION_SPEED)) {
//                Double valueOf = Double.valueOf(Helper.getSpeedMultiplier(ShimejiService.this.getBaseContext()));
//                for (MascotView mascotView : ShimejiService.this.mascotViews) {
//                    mascotView.setSpeedMultiplier(valueOf.doubleValue());
//                }
//            } else if (str.equals(AppConstants.SHOW_NOTIFICATION)) {
//                if (Helper.getNotificationVisibility(ShimejiService.this.getBaseContext())) {
//                    ShimejiService shimejiService = ShimejiService.this;
//                    shimejiService.setForegroundNotification(shimejiService.isShimejiVisible);
//                    return;
//                }
//                if (!ShimejiService.this.isShimejiVisible) {
//                    ShimejiService.this.toggleShimejiStatus();
//                }
//                ShimejiService.this.stopForeground(true);
//            }
//        }
//    }

    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(this.screenStatusReceiver);
        } catch (Exception unused) {
            LogUtil.d(TAG, "Prevented unregister Receiver crash");
        }
        removeMascotViews();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onScreenOff() {
        this.handler.removeMessages(1);
        for (MascotView mascotView : this.mascotViews) {
            if (!mascotView.isHidden) {
                mascotView.pauseAnimation();
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void onScreenOn() {
        LogUtil.d(TAG, "onScreenOn");
        this.handler.removeMessages(1);
        for (MascotView mascotView : this.mascotViews) {
            if (!mascotView.isHidden) {
                mascotView.resumeAnimation();
            }
        }
        this.handler.sendEmptyMessage(1);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setForegroundNotification(boolean z) {
        PendingIntent service = PendingIntent.getActivity(this, 0, new Intent(this, ShimejiSplashActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this);
        Notification.Builder contentTitle = builder.setContentTitle(getString(R.string.shimeji_noti_title));
        Notification.Builder contentIntent = contentTitle.setContentText(getString(R.string.shimeji_noti_msg))
                .setSmallIcon(com.aquarius.anime.common.R.drawable.common_noti_small_icon)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), com.aquarius.anime.common.R.drawable.common_noti_large_icon))
                .setOngoing(true).setPriority(Notification.PRIORITY_MIN).setContentIntent(service);
        if (Build.VERSION.SDK_INT >= 26) {
            setupNotificationChannel();
            contentIntent.setChannelId("notification_channel");
        }
        Notification build = contentIntent.build();
        if (z) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                startForeground(99, build);
            } else {
                startForeground(99, build, FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            }
            return;
        }
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.notify(99, build);

        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void setupNotificationChannel() {
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel notificationChannel = new NotificationChannel("notification_channel", "notification_channel_name", NotificationManager.IMPORTANCE_MIN);
        notificationChannel.setDescription("notification_channel_desc");
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (configuration.orientation == 2 || configuration.orientation == 1) {
            for (MascotView mascotView : this.mascotViews) {
                mascotView.notifyLayoutChange(this);
            }
        }
    }
}