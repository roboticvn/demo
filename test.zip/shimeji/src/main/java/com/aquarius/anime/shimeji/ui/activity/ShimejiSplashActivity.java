package com.aquarius.anime.shimeji.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.data.ShimejiDataManager;
import com.aquarius.anime.shimeji.databinding.ActivityShimejiSplashBinding;
import com.bumptech.glide.Glide;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ShimejiSplashActivity extends BaseActivity {
    private final String TAG = getClass().getSimpleName();
    ActivityShimejiSplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShimejiSplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Glide.with(this).load(com.aquarius.anime.common.R.drawable.common_icon_app).into(binding.ivLogo);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            ShimejiDataManager.syncAllData();
            executor.shutdown();
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startMain();
            }
        }, 2000);
    }

    private void startMain() {
        Intent intent = new Intent(this, ShimejiMainActivity.class);
        startActivity(intent);
        finish();
    }
}