package com.aquarius.anime.shimeji.ui.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;

import androidx.annotation.Nullable;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.ui.dialog.BaseDialogFragment;
import com.aquarius.anime.shimeji.databinding.DialogFreeShimejiBinding;


@SuppressLint("ValidFragment")
public class FreeShimejiDialog extends BaseDialogFragment {
    private final String TAG = getClass().getSimpleName();


    public interface Listener {
        void OnShowGuide();

        void OnRedirect();
    }

    private Listener mListener;


    public FreeShimejiDialog() {

    }

    public FreeShimejiDialog(Listener listener) {
        this.mListener = listener;
    }

    public void download() {
        if (binding.ckbNeverShow.isChecked()) {
            ConfigManager.getInstance().setRedirectShimejiShopConfirm(false);
        }
        if (mListener != null)
            mListener.OnRedirect();
        dismiss();
    }


    public void guide() {
        mListener.OnShowGuide();
        dismiss();
    }


    public void closeDialog() {
        dismiss();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    private DialogFreeShimejiBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCancelable(false);
    }

    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), com.aquarius.anime.common.R.style.RoundDialogTheme);
        binding = DialogFreeShimejiBinding.inflate(LayoutInflater.from(getContext()));
        dialog.setContentView(binding.getRoot());
        binding.btnDownload.setOnClickListener(v -> download());
        binding.btnGuide.setOnClickListener(v -> guide());
        binding.btnCancel.setOnClickListener(v -> closeDialog());
        return dialog;
    }
}
