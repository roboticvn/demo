package com.aquarius.anime.shimeji.ui.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;

import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityTakecarePetBinding;
import com.aquarius.anime.shimeji.util.ShimejiConstants;
import com.otaku.ad.waterfall.AdsManager;

public class TakecarePetActivity extends BaseActivity {

    private Bitmap mBitmap;
    private int mStatus, mId;
    ActivityTakecarePetBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTakecarePetBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AdsManager.getInstance().showBanner(this, binding.banner);

        mStatus = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.HUNGRY);
        mId = getIntent().getIntExtra(ShimejiConstants.EXTRA_MASCOT_ID, -1);
        if (mStatus == TransparentStatusPetActivity.HUNGRY) {
            binding.lottieView.setAnimation("lottie/eat.json");
            binding.lottieView.playAnimation();
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getHungryBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        } else if (mStatus == TransparentStatusPetActivity.DIRTY) {
            binding.lottieView.setAnimation("lottie/wash.json");
            binding.lottieView.playAnimation();
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getDirtyBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        } else if (mStatus == TransparentStatusPetActivity.BORING) {
            binding.lottieView.setAnimation("lottie/play.json");
            binding.lottieView.playAnimation();
            if (mId >= 0) {
                mBitmap = ShimejiDAO.getInstance().getBoringBitmap(mId);
                binding.imageMascot.setImageBitmap(mBitmap);
            }
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(TakecarePetActivity.this, ThankyouActivity.class);
                intent.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mId);
                startActivity(intent);
                finish();
            }
        }, 5000);
    }
}