package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

/* access modifiers changed from: package-private */
public abstract class Jump extends Animation {
    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    Jump(MascotConfig config) {
        super(config);
    }
}
