package com.aquarius.anime.shimeji.ui.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.event.AppEvents;
import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.common.ui.activity.WebviewActivity;
import com.aquarius.anime.common.ui.dialog.DialogManager;
import com.aquarius.anime.common.ui.dialog.RequestPermissionDialog;
import com.aquarius.anime.common.ui.dialog.ShowGuideDialog;
import com.aquarius.anime.common.util.CommonSettingUtil;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.data.MakeShimejiTask;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityShimejiMainBinding;
import com.aquarius.anime.shimeji.lib.ShimejiService;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.ui.adapter.ActiveShimejiAdapter;
import com.aquarius.anime.shimeji.ui.dialog.AddShimejiDialog;
import com.aquarius.anime.shimeji.ui.dialog.SetupShimejiDialog;
import com.aquarius.anime.shimeji.util.ShimejiConfig;
import com.aquarius.anime.shimeji.util.ShimejiConstants;
import com.onesignal.Continue;
import com.onesignal.OneSignal;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;


public class ShimejiMainActivity extends BaseActivity {
    private final String TAG = getClass().getSimpleName();

    private ArrayList<ActiveShimeji> mActiveShimejiList = new ArrayList<>();
    private Context mContext;


    private final ActivityResultLauncher<Intent> overlayPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (!Settings.canDrawOverlays(this)) {
                        ShimejiConfig.setEnableShimeji(false);
                    } else {
                        ShimejiConfig.setEnableShimeji(true);
                    }
                }
            });

    private final ActivityResultLauncher<Intent> openFolderLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null) {
                        try {
                            Uri uri = data.getData();
                            LogUtil.d(TAG, String.valueOf(uri));
                            DocumentFile df = DocumentFile.fromTreeUri(getApplicationContext(), uri);
                            LogUtil.d(TAG, "list_size: " + df.listFiles().length);
                            DialogManager.getInstance().showDialog(getSupportFragmentManager(), new SetupShimejiDialog(new SetupShimejiDialog.Listener() {
                                @Override
                                public void OnSetName(String name) {
                                    showProgressDialog();
                                    new MakeShimejiTask().execute(name, df, new MakeShimejiTask.Listener() {
                                        @Override
                                        public void OnMakeShimejiSuccess() {
                                            hideProgressDialog();
                                            if (ConfigManager.getInstance().isViewModeCategories()) {
                                                Intent intent = new Intent(mContext, CategoryListActivity.class);
                                                startActivity(intent);
                                            } else {
                                                Intent intent = new Intent(mContext, ShimejiListActivity.class);
                                                startActivity(intent);
                                            }
                                        }

                                        @Override
                                        public void OnMakeShimejiFail(String msg) {
                                            Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }

                                @Override
                                public void OnCancel() {

                                }
                            }), "setup_shimeji");

                        } catch (Exception e) {

                        }
                    }
                }
            });
    ActivityShimejiMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShimejiMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mContext = this;
        OneSignal.getNotifications().requestPermission(false, Continue.none());
        ConfigManager.getInstance().setNavigationBarDetect(hasNav(this));

        //--------------- show banner --------------------------------------------
        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        binding.lvShimeji.setLayoutManager(gridLayoutManager);

        binding.btnSettings.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, ShimejiSettingActivity.class);
                startActivity(intent);
            }
        });
        binding.btnJoinCommunity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().fb(ShimejiMainActivity.this);
            }
        });
        binding.btnMoreApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().moreApp(ShimejiMainActivity.this);
            }
        });
        binding.btnGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogManager.getInstance().showDialog(getSupportFragmentManager(), new ShowGuideDialog(getString(R.string.shimeji_guide), new ShowGuideDialog.Listener() {
                    @Override
                    public void OnReadNow() {
                        Intent intent = new Intent(ShimejiMainActivity.this, WebviewActivity.class);
                        intent.putExtra(Constants.INTENT_EXTRA_URL, getString(com.aquarius.anime.common.R.string.shimeji_guide_url));
                        startActivity(intent);
                    }

                    @Override
                    public void OnCancel() {

                    }
                }), "guide");
            }
        });
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (ConfigManager.getInstance().isVip()) binding.tvCoin.setVisibility(View.GONE);
        else binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        binding.tvCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().goToPremium(mContext);
            }
        });

        binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        binding.swtEnable.setOnCheckedChangeListener(null);
        binding.swtEnable.setChecked(false);
        if (ShimejiConfig.isEnableShimeji()) {
            binding.swtEnable.setChecked(true);
        } else binding.swtEnable.setChecked(false);
        binding.swtEnable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                LogUtil.d(TAG, "onCheckedChanged " + isChecked);
                ShimejiConfig.setEnableShimeji(isChecked);
                if (isChecked) {
                    if (checkPermission()) {
                        startService(new Intent(mContext, ShimejiService.class).setAction(ShimejiService.ACTION_START));
                    }
                } else {
                    stopService(new Intent(mContext, ShimejiService.class).setAction(ShimejiService.ACTION_STOP));
                }
            }
        });

        refreshUI();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDataEvent(AppEvents.DataEvent event) {
        switch (event.type) {
            case COIN_CHANGED:
                LogUtil.d(TAG, "COIN_CHANGED event");
                binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
                break;
            default:
                break;
        }
    }

    private void refreshUI() {
        mActiveShimejiList = ShimejiDAO.getInstance().getActiveShimejiList();
        ActiveShimejiAdapter activeShimejiAdapter = new ActiveShimejiAdapter(mActiveShimejiList, new ActiveShimejiAdapter.Listener() {
            @Override
            public void OnRemoveShimejiListener(ActiveShimeji shimeji) {
                ShimejiDAO.getInstance().removeActiveShimeji(shimeji);
                refreshUI();
                Intent intent = new Intent(mContext, ShimejiService.class);
                intent.setAction(ShimejiService.ACTION_REMOVE);
                intent.putExtra(ShimejiConstants.EXTRA_ACTIVE_ID, shimeji.getId());
                startService(intent);
            }

            @Override
            public void OnAddShimejiListener() {
                if (checkPermission()) {
                    DialogManager.getInstance().showDialog(getSupportFragmentManager(), new AddShimejiDialog(new AddShimejiDialog.Listener() {
                        @Override
                        public void OnMakeShimeji() {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                try {
                                    // Android 5.0+ hỗ trợ ACTION_OPEN_DOCUMENT_TREE
                                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                                    openFolderLauncher.launch(intent);
                                } catch (Exception e) {

                                }
                            } else {
                                // Android 4.4 trở xuống không hỗ trợ chọn thư mục
                                // fallback sang chọn file bất kỳ
                                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                                intent.setType("*/*");
                                intent.addCategory(Intent.CATEGORY_OPENABLE);
                                try {
                                    startActivity(Intent.createChooser(intent, "Select a file"));
                                } catch (Exception e) {
                                    Toast.makeText(mContext, getString(com.aquarius.anime.common.R.string.not_activity_to_open), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                        @Override
                        public void OnSelectFromList() {
                            if (ConfigManager.getInstance().isViewModeCategories()) {
                                Intent intent = new Intent(mContext, CategoryListActivity.class);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(mContext, ShimejiListActivity.class);
                                startActivity(intent);
                            }
                        }

                        @Override
                        public void OnCancel() {

                        }
                    }), "add_shimeji");
                }
            }

            @Override
            public void OnShimejiClickListener(ActiveShimeji shimeji) {
                Intent intent = new Intent(mContext, EditShimejiActivity.class);
                intent.putExtra(ShimejiConstants.EXTRA_ACTIVE_ID, shimeji.getId());
                startActivity(intent);
            }
        });
        binding.lvShimeji.setAdapter(activeShimejiAdapter);
    }

    public boolean checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                DialogManager.getInstance().showDialog(getSupportFragmentManager(), new RequestPermissionDialog(getString(R.string.shimeji_overlay_request_permission), new RequestPermissionDialog.Listener() {
                    @Override
                    public void OnGrantPermission() {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        overlayPermissionLauncher.launch(intent);
                    }

                    @Override
                    public void OnCancel() {
                        ShimejiConfig.setEnableShimeji(false);
                        binding.swtEnable.setChecked(false);
                    }
                }), "request_overlay_permission");
                return false;
            } else {
                ShimejiConfig.setEnableShimeji(true);
                return true;
            }
        } else {
            return true;
        }
    }

    public boolean hasNav(Activity activity) {
        final float MIN_HEIGHT_DP = 20f;

        DisplayMetrics realMetrics = new DisplayMetrics();
        DisplayMetrics usableMetrics = new DisplayMetrics();

        // Dùng cách cũ cho tất cả phiên bản
        activity.getWindowManager().getDefaultDisplay().getRealMetrics(realMetrics);
        activity.getWindowManager().getDefaultDisplay().getMetrics(usableMetrics);

        int realHeight = realMetrics.heightPixels;
        int usableHeight = usableMetrics.heightPixels;

        int navBarHeight = realHeight - usableHeight;
        float dp = navBarHeight / activity.getResources().getDisplayMetrics().density;

        return dp > MIN_HEIGHT_DP;
    }
}
