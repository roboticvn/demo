package com.aquarius.anime.shimeji.util;

import com.aquarius.anime.common.util.AppContextHolder;
import com.aquarius.anime.common.util.SharedPreferenceUtil;
import com.aquarius.anime.shimeji.petcare.PetCareAlertMngr;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.ActiveShimeji;

import java.util.ArrayList;

public class ShimejiConfig {
    static final String TAG = "ShimejiConfig";

    public static boolean isEnableShimeji() {
        return SharedPreferenceUtil.getInstance().getBoolean("enable_shimeji", false);
    }

    public static void setEnableShimeji(boolean value) {
        SharedPreferenceUtil.getInstance().putBoolean("enable_shimeji", value);
        try {
            ArrayList<ActiveShimeji> activeShimejis = ShimejiDAO.getInstance().getActiveShimejiList();
            if (value) {
                for (ActiveShimeji shimeji : activeShimejis) {
                    PetCareAlertMngr.getInstance().setAlarms(AppContextHolder.getContext(), shimeji.getId(), shimeji.getTimeAdded());
                }
            } else {
                for (ActiveShimeji shimeji : activeShimejis) {
                    PetCareAlertMngr.getInstance().stopAlarms(AppContextHolder.getContext(), shimeji.getId());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean isEnablePetCare() {
        return SharedPreferenceUtil.getInstance().getBoolean("pet_care", true);
    }
    public static void setEnablePetCare(boolean value) {
        SharedPreferenceUtil.getInstance().putBoolean("pet_care", value);
    }

    public static int getIdIncreasement() {
        return SharedPreferenceUtil.getInstance().getInt("unique_id", 200000);
    }

    public static void saveIdIncreasement() {
        int maxId = SharedPreferenceUtil.getInstance().getInt("unique_id", 200000);
        SharedPreferenceUtil.getInstance().putInt("unique_id", (maxId + 1));
    }
}
