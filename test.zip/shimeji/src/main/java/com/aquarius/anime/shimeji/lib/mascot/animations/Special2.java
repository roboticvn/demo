package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

/* access modifiers changed from: package-private */
public abstract class Special2 extends Animation {
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return true;
    }

    Special2(MascotConfig config) {
        super(config);
    }
}