package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

public class ClimbRight extends Climb {
    ClimbRight(MascotConfig config) {
        super(config);
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Climb, com.digitalcosmos.shimeji.mascot.animations.Animation
    public /* bridge */ /* synthetic */ void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        super.checkBorders(z, z2, z3, z4);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new ClimbCeilingLeft(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getOptionalAnimation() {
        return this.random.nextInt(100) < 70 ? new JumpLeft(config) : new Falling(getDirection(), config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.RIGHT;
    }
}
