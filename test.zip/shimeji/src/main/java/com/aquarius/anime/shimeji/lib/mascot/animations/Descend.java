package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public abstract class Descend extends Animation {
    Descend(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(13, 0, 0, 16));
        arrayList.add(new Sprite(13, 0, 2, 4));
        arrayList.add(new Sprite(11, 0, 2, 4));
        arrayList.add(new Sprite(12, 0, 2, 4));
        arrayList.add(new Sprite(12, 0, 0, 16));
        arrayList.add(new Sprite(12, 0, 1, 4));
        arrayList.add(new Sprite(11, 0, 1, 4));
        arrayList.add(new Sprite(13, 0, 1, 4));
        return arrayList;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z2;
    }
}
