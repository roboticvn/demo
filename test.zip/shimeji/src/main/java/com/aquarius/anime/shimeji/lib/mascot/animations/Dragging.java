package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class Dragging extends Animation {
    private Direction direction;

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public boolean getIsOneShot() {
        return false;
    }

    public Dragging(MascotConfig config) {
        super(config);
        this.direction = this.random.nextBoolean() ? Direction.LEFT : Direction.RIGHT;
    }

    public Animation drop() {
        return getNextAnimation();
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(6, 0, 0, 8));
        arrayList.add(new Sprite(4, 0, 0, 8));
        arrayList.add(new Sprite(5, 0, 0, 8));
        arrayList.add(new Sprite(7, 0, 0, 8));
        arrayList.add(new Sprite(5, 0, 0, 8));
        arrayList.add(new Sprite(4, 0, 0, 8));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new Falling(this.direction, config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return this.direction;
    }
}
