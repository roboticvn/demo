package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

import java.util.ArrayList;
import java.util.List;

public final class JumpLeft extends Jump {
    JumpLeft(MascotConfig config) {
        super(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public List<Sprite> getSprites() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new Sprite(21, -10, -1, 2));
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new ClimbLeft(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.LEFT;
    }

    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        this.nextAnimationRequested = z3;
    }
}
