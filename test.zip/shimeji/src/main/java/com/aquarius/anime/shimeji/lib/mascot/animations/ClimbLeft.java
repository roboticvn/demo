package com.aquarius.anime.shimeji.lib.mascot.animations;

import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;

public class ClimbLeft extends Climb {
    ClimbLeft(MascotConfig config) {
        super(config);
    }

    @Override
    // com.digitalcosmos.shimeji.mascot.animations.Climb, com.digitalcosmos.shimeji.mascot.animations.Animation
    public /* bridge */ /* synthetic */ void checkBorders(boolean z, boolean z2, boolean z3, boolean z4) {
        super.checkBorders(z, z2, z3, z4);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getNextAnimation() {
        return new ClimbCeilingRight(config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Animation getOptionalAnimation() {
        return this.random.nextInt(100) < 70 ? new JumpRight(config) : new Falling(getDirection(), config);
    }

    /* access modifiers changed from: package-private */
    @Override // com.digitalcosmos.shimeji.mascot.animations.Animation
    public Direction getDirection() {
        return Direction.LEFT;
    }
}
