package com.aquarius.anime.shimeji.model;

import androidx.annotation.Nullable;

public class Category {
    private String name;
    private String thumb;

    private int noOfPet;

    public Category() {
    }

    public Category(String name, String thumb, int noOfPet) {
        this.name = name;
        this.thumb = thumb;
        this.noOfPet = noOfPet;
    }

    public String getName() {
        return name;
    }

    public Category setName(String name) {
        this.name = name;
        return this;
    }

    public String getThumb() {
        return thumb;
    }

    public Category setThumb(String thumb) {
        this.thumb = thumb;
        return this;
    }

    public int getNoOfPet() {
        return noOfPet;
    }

    public Category setNoOfPet(int noOfPet) {
        this.noOfPet = noOfPet;
        return this;
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (this.name.equals(((Category) obj).name)) return true;
        return false;
    }
}
