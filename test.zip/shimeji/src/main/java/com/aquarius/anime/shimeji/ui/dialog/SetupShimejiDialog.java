package com.aquarius.anime.shimeji.ui.dialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.aquarius.anime.common.ui.dialog.BaseDialogFragment;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.DialogSetupShimejiBinding;


public class SetupShimejiDialog extends BaseDialogFragment {
    private final String TAG = getClass().getSimpleName();

    public interface Listener {
        void OnSetName(String name);

        void OnCancel();
    }

    private Listener mListener;


    public SetupShimejiDialog() {

    }

    public void cancel() {
        mListener.OnCancel();
        dismiss();
    }

    public void create(DialogSetupShimejiBinding binding) {
        String name = binding.edtName.getText().toString();
        if (name.length() == 0)
            Toast.makeText(getContext(), getString(R.string.please_enter_name), Toast.LENGTH_SHORT).show();
        else if (ShimejiDAO.getInstance().checkShimejiExist(name)) {
            Toast.makeText(getContext(), getString(R.string.enter_different_name), Toast.LENGTH_SHORT).show();
        } else {
            try {
                mListener.OnSetName(binding.edtName.getText().toString());
            } catch (Exception e) {
                LogUtil.e(TAG, e.getMessage());
            }
            dismiss();
        }
    }


    public SetupShimejiDialog(Listener listener) {
        mListener = listener;
    }

    DialogSetupShimejiBinding binding;

    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getContext(), com.aquarius.anime.common.R.style.RoundDialogTheme);
        binding = DialogSetupShimejiBinding.inflate(LayoutInflater.from(getContext()));
        dialog.setContentView(binding.getRoot());
        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancel();
            }
        });
        binding.btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                create(binding);
            }
        });
        return dialog;
    }
}


