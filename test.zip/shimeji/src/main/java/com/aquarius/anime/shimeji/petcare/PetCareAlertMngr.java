package com.aquarius.anime.shimeji.petcare;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.model.ActiveShimeji;
import com.aquarius.anime.shimeji.ui.activity.TransparentStatusPetActivity;
import com.aquarius.anime.shimeji.util.ShimejiConstants;

import java.util.Calendar;
import java.util.Date;

public class PetCareAlertMngr {
    private final String TAG = "Alert_" + getClass().getSimpleName();

    private PetCareAlertMngr() {

    }

    private static PetCareAlertMngr instance;

    public static PetCareAlertMngr getInstance() {
        if (instance == null)
            instance = new PetCareAlertMngr();
        return instance;
    }

    public void setAlarms(Context context, int mascotActiveID, long time) {
        try {
            LogUtil.d(TAG, "setAlarms: " + mascotActiveID);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            ActiveShimeji activeShimeji = ShimejiDAO.getInstance().getActiveShimejiByID(mascotActiveID);
            int mascotID = activeShimeji.getMascotID();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date(time));

            // Alarm 1: time + 4 hours, repeat every 4 hours

            calendar.add(Calendar.HOUR_OF_DAY, 4);
            long alarmTime1 = calendar.getTimeInMillis();
            Intent intent1 = new Intent(context, PetCareAlarmReceiver.class);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mascotID);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.HUNGRY);
            LogUtil.d(TAG, "request code: " + (mascotActiveID * 10 + 1));
            boolean alarmHungry = (PendingIntent.getBroadcast(context, mascotActiveID * 10 + 1,
                    intent1,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE) != null);
            if (!alarmHungry) {
                PendingIntent pendingIntent1 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 1, intent1,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                LogUtil.d(TAG, "setAlarms_start: " + mascotActiveID);
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, alarmTime1, 4 * 60 * 60 * 1000, pendingIntent1);
            } else {
                LogUtil.d(TAG, "setAlarms_exist: " + mascotActiveID);
            }

            // Alarm 2: time + 6 hours, repeat every 6 hours
            calendar.add(Calendar.HOUR_OF_DAY, 6);
            long alarmTime2 = calendar.getTimeInMillis();
            Intent intent2 = new Intent(context, PetCareAlarmReceiver.class);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mascotID);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.BORING);

            boolean alarmBoring = (PendingIntent.getBroadcast(context, mascotActiveID * 10 + 2,
                    intent2,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE) != null);
            if (!alarmBoring) {
                PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 2, intent2,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, alarmTime2, 6 * 60 * 60 * 1000, pendingIntent2);
            }

            // Alarm 3: time + 8 hours, repeat every 8 hours
            calendar.add(Calendar.HOUR_OF_DAY, 8);
            long alarmTime3 = calendar.getTimeInMillis();
            Intent intent3 = new Intent(context, PetCareAlarmReceiver.class);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mascotID);
            intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.DIRTY);
            boolean alarmDiry = (PendingIntent.getBroadcast(context, mascotActiveID * 10 + 3,
                    intent3,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE) != null);
            if (!alarmDiry) {
                PendingIntent pendingIntent3 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 3, intent3,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, alarmTime3, 8 * 60 * 60 * 1000, pendingIntent3);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopAlarms(Context context, int mascotActiveID) {
        try {
            LogUtil.d(TAG, "stopAlarms: " + mascotActiveID);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            // Cancel Alarm 1
            Intent intent1 = new Intent(context, PetCareAlarmReceiver.class);
            PendingIntent pendingIntent1 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 1, intent1,
                    PendingIntent.FLAG_UPDATE_CURRENT| PendingIntent.FLAG_IMMUTABLE);
            alarmManager.cancel(pendingIntent1);

            // Cancel Alarm 2
            Intent intent2 = new Intent(context, PetCareAlarmReceiver.class);
            PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 2, intent2,
                    PendingIntent.FLAG_UPDATE_CURRENT| PendingIntent.FLAG_IMMUTABLE);
            alarmManager.cancel(pendingIntent2);

            // Cancel Alarm 3
            Intent intent3 = new Intent(context, PetCareAlarmReceiver.class);
            PendingIntent pendingIntent3 = PendingIntent.getBroadcast(context, mascotActiveID * 10 + 3, intent3,
                    PendingIntent.FLAG_UPDATE_CURRENT| PendingIntent.FLAG_IMMUTABLE);
            alarmManager.cancel(pendingIntent3);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
