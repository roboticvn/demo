package com.aquarius.anime.shimeji.petcare;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.ui.activity.TransparentStatusPetActivity;
import com.aquarius.anime.shimeji.util.ShimejiConfig;
import com.aquarius.anime.shimeji.util.ShimejiConstants;

public class PetCareAlarmReceiver extends BroadcastReceiver {
    private final String TAG = "Alert_" + getClass().getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        LogUtil.d(TAG, "onReceive");
       try {
            LogUtil.d(TAG, "onReceive: " + intent.getIntExtra(ShimejiConstants.EXTRA_MASCOT_ID, -1));
            int mascotID = intent.getIntExtra(ShimejiConstants.EXTRA_MASCOT_ID, -1);
            int status = intent.getIntExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, TransparentStatusPetActivity.HUNGRY);
            boolean enable = ShimejiConfig.isEnablePetCare();
            boolean active = ShimejiConfig.isEnableShimeji();
            if (mascotID > -1 && enable && active) {
                Intent intent1 = new Intent(context, TransparentStatusPetActivity.class);
                intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_ID, mascotID);
                intent1.putExtra(ShimejiConstants.EXTRA_MASCOT_STATUS, status);
                context.startActivity(intent1);
            }
       } catch (Exception e) {
           e.printStackTrace();
       }
    }
}