package com.aquarius.anime.shimeji.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aquarius.anime.common.config.ConfigManager;
import com.aquarius.anime.common.event.AppEvents;
import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.common.ui.activity.PremiumActivity;
import com.aquarius.anime.common.ui.activity.WebviewActivity;
import com.aquarius.anime.common.ui.dialog.DialogManager;
import com.aquarius.anime.common.ui.dialog.UnlockItemDialog;
import com.aquarius.anime.common.util.CommonSettingUtil;
import com.aquarius.anime.common.util.Constants;
import com.aquarius.anime.common.util.InternetConnectionUtil;
import com.aquarius.anime.common.util.LogUtil;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.database.ShimejiDAO;
import com.aquarius.anime.shimeji.databinding.ActivityShimejiListBinding;
import com.aquarius.anime.shimeji.lib.mascot.MascotConfig;
import com.aquarius.anime.shimeji.model.Shimeji;
import com.aquarius.anime.shimeji.model.ShimejiMap;
import com.aquarius.anime.shimeji.ui.adapter.ShimejiAdapter;
import com.aquarius.anime.shimeji.ui.dialog.FreeShimejiDialog;
import com.aquarius.anime.shimeji.ui.dialog.SelectViewModeDialog;
import com.aquarius.anime.shimeji.util.ShimejiConstants;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;

public class ShimejiListActivity extends BaseActivity {
    private final String TAG = getClass().getSimpleName();
    private Context mContext;
    private ShimejiAdapter shimejiAdapter;
    private String categoryName = null;

    ActivityShimejiListBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShimejiListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mContext = this;

        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        categoryName = getIntent().getStringExtra(Constants.INTENT_EXTRA_CATEGORY);

        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        binding.btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogManager.getInstance().showDialog(getSupportFragmentManager(), new SelectViewModeDialog(new SelectViewModeDialog.Listener() {
                    @Override
                    public void OnSelectCategoriesMode(boolean enable) {
                        ConfigManager.getInstance().setViewModeCategories(enable);
                        if (enable) {
                            Intent intent = new Intent(mContext, CategoryListActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                }), "select_view_mode");
            }
        });
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        binding.lvShimeji.setLayoutManager(layoutManager);

        binding.edtSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.edtSearch.requestFocus();
            }
        });

        binding.edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                Handler mHandler = new Handler();
                mHandler.removeCallbacksAndMessages(null);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Put your call to the server here (with mQueryString)
                        shimejiAdapter.getFilter().filter(editable.toString());
                    }
                }, 400);

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ConfigManager.getInstance().isVip()) binding.tvCoin.setVisibility(View.GONE);
        else binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        binding.tvCoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommonSettingUtil.getInstance().goToPremium(mContext);
            }
        });
        refreshUI();
    }

    private void refreshUI() {
        if (!InternetConnectionUtil.checkConnection(this)) {
            Toast.makeText(this, getString(com.aquarius.anime.common.R.string.no_internet), Toast.LENGTH_SHORT).show();
        }

        binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
        ArrayList<Shimeji> shimejiList = ShimejiDAO.getInstance().getShimejiList(categoryName);
        shimejiAdapter = new ShimejiAdapter(shimejiList, new ShimejiAdapter.Listener() {
            @Override
            public void OnItemClickListener(int position, final Shimeji shimeji, ShimejiMap map) {
                if (map != null) {
                    LogUtil.d(TAG, "show_again: " + ConfigManager.getInstance().isRedirectShimejiShopConfirm());
                    if (ConfigManager.getInstance().isRedirectShimejiShopConfirm()) {
                        DialogManager.getInstance().showDialog(getSupportFragmentManager(), new FreeShimejiDialog(new FreeShimejiDialog.Listener() {
                            @Override
                            public void OnShowGuide() {
                                Intent intent = new Intent(mContext, WebviewActivity.class);
                                intent.putExtra(Constants.INTENT_EXTRA_URL, getString(com.aquarius.anime.common.R.string.shimeji_guide_url));
                                startActivity(intent);
                            }

                            @Override
                            public void OnRedirect() {
                                Intent intent = new Intent(mContext, WebviewActivity.class);
                                intent.putExtra(Constants.INTENT_EXTRA_URL, map.getUrl());
                                startActivity(intent);
                            }
                        }), "free_shimeji");
                    } else {
                        Intent intent = new Intent(mContext, WebviewActivity.class);
                        intent.putExtra(Constants.INTENT_EXTRA_URL, map.getUrl());
                        startActivity(intent);
                    }
                } else {
                    if (shimeji.getLock() == MascotConfig.LOCK) {
                        DialogManager.getInstance().showDialog(getSupportFragmentManager(), new UnlockItemDialog(new UnlockItemDialog.Listener() {
                            @Override
                            public void OnPremium() {
                                Intent intent = new Intent(ShimejiListActivity.this, PremiumActivity.class);
                                startActivity(intent);
                            }

                            @Override
                            public void OnUnlockByCoin() {
                                shimeji.setLock(MascotConfig.UNLOCK);
                                ShimejiDAO.getInstance().updateShimeji(shimeji);
                                ConfigManager.getInstance().minusCoins(ShimejiConstants.SHIMEJI_UNLOCK_COINS);
                                shimejiAdapter.notifyItemRangeChanged(position, shimejiAdapter.getItemCount());
                            }
                        }), "unlock_shimeji");
                    } else {
                        if (ShimejiDAO.getInstance().checkShimejiDownloaded(shimeji.getMascotID())) {
                            Intent intent = new Intent(mContext, ShimejiDetailActivity.class);
                            intent.putExtra(ShimejiConstants.EXTRA_SHIMEJI, shimeji);
                            startActivity(intent);
                        } else {
                            Toast.makeText(mContext, getString(R.string.need_download), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        binding.lvShimeji.setAdapter(shimejiAdapter);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDataEvent(AppEvents.DataEvent event) {
        switch (event.type) {
            case SHIMEJI_CHANGED:
                refreshUI();
                break;
            case COIN_CHANGED:
                LogUtil.d(TAG, "COIN_CHANGED event");
                binding.tvCoin.setText("" + ConfigManager.getInstance().getCoins());
                break;
        }
    }
}
