package com.aquarius.anime.shimeji.ui.activity;

import android.os.Bundle;
import android.view.View;

import com.aquarius.anime.common.ui.activity.BaseActivity;
import com.aquarius.anime.common.ui.fragment.CommonSettingFragment;
import com.aquarius.anime.shimeji.R;
import com.aquarius.anime.shimeji.databinding.ActivityShimejiSettingBinding;
import com.aquarius.anime.shimeji.util.ShimejiConfig;
import com.otaku.ad.waterfall.AdsManager;
import com.otaku.ad.waterfall.listener.PopupAdsListener;

public class ShimejiSettingActivity extends BaseActivity {

    ActivityShimejiSettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShimejiSettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        AdsManager.getInstance().showBanner(this, binding.banner);
        AdsManager.getInstance().showPopup(this, new PopupAdsListener() {
            @Override
            public void OnClose() {

            }

            @Override
            public void OnShowFail() {

            }
        });

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.shimeji_common_setting_container, new CommonSettingFragment())
                .commit();

        binding.swtPetCare.setChecked(ShimejiConfig.isEnablePetCare());

        binding.btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        binding.rowSettingPetCare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean enable = ShimejiConfig.isEnablePetCare();
                ShimejiConfig.setEnablePetCare(!enable);
                binding.swtPetCare.setChecked(!enable);
            }
        });

    }
}